# بازی خونه Native Flutter v4

این نسخه تبدیل Native Flutter از نسخه HTML `game_fix59_maropelleh_bigger_board_compact_top` است و WebView ندارد.

تمرکز نسخه:
- بازسازی UI نزدیک به نسخه HTML با رنگ‌ها، کارت‌ها، آیکن‌ها و تصاویر استخراج‌شده از HTML v59
- صفحه اصلی، فروشگاه، لیگ، جوایز، پروفایل، آموزش سریع، پشتیبانی، بازی با دوستان
- بازی 2048 و ماروپله با منطق Dart/Flutter
- ساختار آماده GitHub Actions برای خروجی APK و AAB

برای گرفتن خروجی، ZIP را در GitHub آپلود کنید و workflow را اجرا کنید.
