from pathlib import Path
bad=['webview_flutter','InAppWebView','HtmlElementView','Flutter Demo Home Page']
root=Path(__file__).resolve().parents[1]
text='\n'.join(p.read_text(errors='ignore') for p in list((root/'lib').glob('**/*.dart'))+[root/'pubspec.yaml'])
for b in bad:
    if b in text:
        raise SystemExit(f'Forbidden marker found: {b}')
print('OK: native Flutter, no WebView/demo markers')
