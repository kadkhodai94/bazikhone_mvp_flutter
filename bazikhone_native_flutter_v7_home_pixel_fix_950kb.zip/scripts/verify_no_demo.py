from pathlib import Path
p=Path('lib/main.dart')
text=p.read_text(encoding='utf-8') if p.exists() else ''
bad=['Flutter Demo Home Page','You have pushed the button','MyHomePage','_MyHomePageState','Counter','webview_flutter','InAppWebView','HtmlElementView','WebView']
found=[x for x in bad if x in text]
if found:
    raise SystemExit('Invalid generated app. Found: '+', '.join(found))
required=['BaziKhonehApp','Game2048','SnakeLadder']
missing=[x for x in required if x not in text]
if missing:
    raise SystemExit('Missing native app markers: '+', '.join(missing))
print('OK: native BaziKhoneh app, no Flutter demo, no WebView')
