import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const BaziKhonehApp());

const Color bg = Color(0xfffff1d9);
const Color cream = Color(0xfffff7ea);
const Color purple = Color(0xff3b075f);
const Color purple2 = Color(0xff7a0cc6);
const Color pink = Color(0xffdf2b90);
const Color orange = Color(0xffff7a18);
const Color gold = Color(0xffffd867);
const Color textColor = Color(0xff2e1447);

BoxDecoration appBox(Color color, {double radius = 24}) {
  return BoxDecoration(
    color: color,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: Colors.white.withOpacity(.55), width: 1.2),
    boxShadow: [
      BoxShadow(
        color: purple.withOpacity(.16),
        blurRadius: 24,
        offset: const Offset(0, 10),
      ),
    ],
  );
}

class Asset {
  static const String coin = 'assets/images/asset_00_114b2055.webp';
  static const String hero = 'assets/images/asset_01_23ff2102.webp';
  static const String support = 'assets/images/asset_20_1e5b8ba8.webp';
  static const String guide = 'assets/images/asset_21_c6c64bc9.webp';
  static const String rewards = 'assets/images/asset_11_90a68fa2.webp';
  static const String daily = 'assets/images/asset_33_8f971846.webp';
  static const String league = 'assets/images/asset_34_17013e04.webp';
  static const String bronze = 'assets/images/asset_59_de316c85.webp';
  static const String silver = 'assets/images/asset_35_4df83a21.webp';
  static const String goldLeague = 'assets/images/asset_60_29f151c2.webp';
  static const String diamond = 'assets/images/asset_61_57a37b62.webp';
  static const String legend = 'assets/images/asset_62_bcc7bc0e.webp';
  static const String friend = 'assets/images/asset_58_35629837.webp';

  static const List<String> games = [
    'assets/images/asset_04_4d678f2f.webp',
    'assets/images/asset_08_26f7a23b.webp',
    'assets/images/asset_02_e15b56d1.webp',
    'assets/images/asset_03_9365f089.webp',
    'assets/images/asset_06_cfd497bf.webp',
    'assets/images/asset_07_2181069e.webp',
    'assets/images/asset_09_655aff23.webp',
  ];

  static const List<String> avatars = [
    'assets/images/asset_12_1900cad8.webp',
    'assets/images/asset_13_3a3b4480.webp',
    'assets/images/asset_14_36141f39.webp',
    'assets/images/asset_15_9b9e986e.webp',
    'assets/images/asset_16_bf571ce0.webp',
    'assets/images/asset_17_045093b3.webp',
    'assets/images/asset_18_7be76c91.webp',
    'assets/images/asset_19_bf1256f2.webp',
    'assets/images/asset_41_3aa6f693.webp',
    'assets/images/asset_43_5f1aad78.webp',
    'assets/images/asset_48_1d7b31b9.webp',
    'assets/images/asset_52_d6e00aad.webp',
  ];
}

class BaziKhonehApp extends StatelessWidget {
  const BaziKhonehApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بازی خونه',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: purple),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: Shell(),
      ),
    );
  }
}

class Store extends ChangeNotifier {
  int coins = 2500;
  int xp = 180;
  int energy = 10;
  int avatar = 0;
  int wins = 0;
  SharedPreferences? sp;

  Future<void> load() async {
    sp = await SharedPreferences.getInstance();
    coins = sp!.getInt('coins') ?? 2500;
    xp = sp!.getInt('xp') ?? 180;
    energy = sp!.getInt('energy') ?? 10;
    avatar = sp!.getInt('avatar') ?? 0;
    wins = sp!.getInt('wins') ?? 0;
    notifyListeners();
  }

  void save() {
    sp?.setInt('coins', coins);
    sp?.setInt('xp', xp);
    sp?.setInt('energy', energy);
    sp?.setInt('avatar', avatar);
    sp?.setInt('wins', wins);
  }

  void add(int c, {int x = 0}) {
    coins += c;
    xp += x;
    if (c > 0) wins++;
    save();
    notifyListeners();
  }

  bool spend(int c) {
    if (coins < c) return false;
    coins -= c;
    save();
    notifyListeners();
    return true;
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final Store store = Store();
  int tab = 0;
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    store.load().then((_) => setState(() => loaded = true));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      Home(store: store),
      Shop(store: store),
      League(store: store),
      Profile(store: store),
    ];
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: bg,
          body: SafeArea(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topLeft,
                  radius: 1.2,
                  colors: [Colors.white, bg],
                ),
              ),
              child: loaded ? pages[tab] : const Center(child: CircularProgressIndicator()),
            ),
          ),
          bottomNavigationBar: tab == 0
              ? Nav(tab: tab, onTap: (i) => setState(() => tab = i))
              : null,
        );
      },
    );
  }
}

class Nav extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onTap;
  const Nav({super.key, required this.tab, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const items = [('خانه', 0), ('فروشگاه', 1), ('لیگ', 2), ('پروفایل', 3)];
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      padding: const EdgeInsets.all(8),
      decoration: appBox(purple),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          for (final item in items)
            GestureDetector(
              onTap: () => onTap(item.$2),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: item.$2 == tab ? appBox(gold) : null,
                child: Text(
                  item.$1,
                  style: TextStyle(
                    color: item.$2 == tab ? purple : Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String text;
  final String? image;
  const Pill({super.key, required this.text, this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: appBox(cream, radius: 18),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (image != null) Image.asset(image!, height: 22),
          if (image != null) const SizedBox(width: 4),
          Text(text, style: const TextStyle(color: purple, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  final Store store;
  const Header(this.store, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
      child: Row(
        children: [
          CircleAvatar(
            radius: 25,
            backgroundImage: AssetImage(Asset.avatars[store.avatar % Asset.avatars.length]),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('بازی خونه', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: purple)),
                Text('سرگرمی کوتاه، رقابت، جایزه', style: TextStyle(color: textColor.withOpacity(.65), fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Pill(image: Asset.coin, text: '${store.coins}'),
          const SizedBox(width: 7),
          Pill(text: '⚡ ${store.energy}'),
        ],
      ),
    );
  }
}

class Home extends StatelessWidget {
  final Store store;
  const Home({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(0, 0, 0, 18),
      children: [
        Header(store),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: Image.asset(Asset.hero, fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 14),
        GameGrid(store: store),
        const SizedBox(height: 12),
        WideActionCard(
          image: Asset.friend,
          title: 'بازی با دوستان',
          sub: 'ساخت اتاق خصوصی یا ورود با کد',
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FriendPage(store: store))),
        ),
        const SizedBox(height: 10),
        WideActionCard(
          image: Asset.guide,
          title: 'آموزش سریع',
          sub: 'قوانین، نکته‌ها و راهنمای بازی',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const InfoPage(
                title: 'آموزش سریع',
                image: Asset.guide,
                body: 'هر بازی کوتاه است. سکه برای راهنما، خرید آواتار و شرکت در لیگ مصرف می‌شود. برد مرحله سکه و XP می‌دهد.',
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        WideActionCard(
          image: Asset.rewards,
          title: 'جوایز ویژه',
          sub: 'جایزه روزانه، مأموریت و پاداش',
          onTap: () => store.add(200, x: 10),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

class WideActionCard extends StatelessWidget {
  final String image;
  final String title;
  final String sub;
  final VoidCallback onTap;
  const WideActionCard({super.key, required this.image, required this.title, required this.sub, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 86,
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        decoration: appBox(cream, radius: 28),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Image.asset(image, width: 104, height: 64, fit: BoxFit.cover),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Text(title, maxLines: 1, style: const TextStyle(color: purple, fontSize: 22, fontWeight: FontWeight.w900)),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    sub,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: textColor.withOpacity(.62), fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.chevron_left_rounded, color: purple, size: 34),
          ],
        ),
      ),
    );
  }
}

class ActionCard extends StatelessWidget {
  final String image;
  final String title;
  final String sub;
  final VoidCallback onTap;
  const ActionCard({super.key, required this.image, required this.title, required this.sub, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return WideActionCard(image: image, title: title, sub: sub, onTap: onTap);
  }
}

class GameGrid extends StatelessWidget {
  final Store store;
  const GameGrid({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final titles = ['2048', 'ماروپله', 'حافظه کارت‌ها', 'دوز مهره‌ای', 'نقطه خط', 'XOX', 'شطرنج'];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: .78,
        crossAxisSpacing: 12,
        mainAxisSpacing: 14,
      ),
      itemCount: titles.length,
      itemBuilder: (context, i) {
        return GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) {
                if (i == 0) return Game2048(store: store);
                if (i == 1) return SnakeLadder(store: store);
                return MiniGame(title: titles[i], image: Asset.games[i], store: store);
              },
            ),
          ),
          child: Container(
            decoration: appBox(Colors.white, radius: 28),
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
            child: Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(Asset.games[i], fit: BoxFit.contain, width: double.infinity),
                  ),
                ),
                const SizedBox(height: 5),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(titles[i], maxLines: 1, style: const TextStyle(color: purple, fontSize: 20, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 2),
                const Text('شروع بازی', maxLines: 1, style: TextStyle(color: pink, fontSize: 15, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        );
      },
    );
  }
}

class GamePage extends StatelessWidget {
  final String title;
  final Widget child;
  const GamePage({super.key, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        centerTitle: true,
        title: Text(title, style: const TextStyle(color: purple, fontWeight: FontWeight.w900)),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: purple), onPressed: () => Navigator.pop(context)),
      ),
      body: child,
    );
  }
}

class Game2048 extends StatefulWidget {
  final Store store;
  const Game2048({super.key, required this.store});
  @override
  State<Game2048> createState() => _Game2048State();
}

class _Game2048State extends State<Game2048> {
  List<int> board = List.filled(16, 0);
  int score = 0;
  int best = 0;
  final Random rnd = Random();

  @override
  void initState() {
    super.initState();
    reset();
  }

  void reset() {
    board = List.filled(16, 0);
    score = 0;
    addTile();
    addTile();
    setState(() {});
  }

  void addTile() {
    final empty = [for (int i = 0; i < 16; i++) if (board[i] == 0) i];
    if (empty.isNotEmpty) {
      board[empty[rnd.nextInt(empty.length)]] = rnd.nextDouble() < .9 ? 2 : 4;
    }
  }

  List<int> mergeLine(List<int> line) {
    final values = line.where((e) => e > 0).toList();
    for (int i = 0; i < values.length - 1; i++) {
      if (values[i] == values[i + 1]) {
        values[i] *= 2;
        score += values[i];
        values.removeAt(i + 1);
      }
    }
    while (values.length < 4) {
      values.add(0);
    }
    return values;
  }

  void move(int direction) {
    final old = board.join(',');
    for (int r = 0; r < 4; r++) {
      final line = <int>[];
      for (int c = 0; c < 4; c++) {
        final idx = direction < 2
            ? r * 4 + (direction == 0 ? c : 3 - c)
            : (direction == 2 ? c * 4 + r : (3 - c) * 4 + r);
        line.add(board[idx]);
      }
      final merged = mergeLine(line);
      for (int c = 0; c < 4; c++) {
        final idx = direction < 2
            ? r * 4 + (direction == 0 ? c : 3 - c)
            : (direction == 2 ? c * 4 + r : (3 - c) * 4 + r);
        board[idx] = merged[c];
      }
    }
    if (old != board.join(',')) {
      addTile();
      if (score > best) best = score;
      if (board.contains(2048)) widget.store.add(500, x: 50);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return GamePage(
      title: '2048',
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Pill(text: 'امتیاز $score'),
                const SizedBox(width: 8),
                Pill(text: 'بهترین $best'),
                const Spacer(),
                ElevatedButton(onPressed: reset, child: const Text('شروع دوباره')),
              ],
            ),
          ),
          Expanded(
            child: GestureDetector(
              onHorizontalDragEnd: (e) => move((e.primaryVelocity ?? 0) < 0 ? 0 : 1),
              onVerticalDragEnd: (e) => move((e.primaryVelocity ?? 0) < 0 ? 2 : 3),
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Container(
                    margin: const EdgeInsets.all(16),
                    padding: const EdgeInsets.all(10),
                    decoration: appBox(purple, radius: 30),
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                      ),
                      itemCount: 16,
                      itemBuilder: (_, i) {
                        final value = board[i];
                        return Container(
                          alignment: Alignment.center,
                          decoration: appBox(value == 0 ? const Color(0xff662084) : gold, radius: 16),
                          child: Text(
                            value == 0 ? '' : '$value',
                            style: TextStyle(
                              color: value == 0 ? Colors.white : purple,
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SnakeLadder extends StatefulWidget {
  final Store store;
  const SnakeLadder({super.key, required this.store});
  @override
  State<SnakeLadder> createState() => _SnakeLadderState();
}

class _SnakeLadderState extends State<SnakeLadder> {
  int me = 1;
  int bot = 1;
  int dice = 1;
  final Random rnd = Random();
  final Map<int, int> jump = {4: 14, 9: 31, 20: 38, 28: 84, 17: 7, 54: 34, 62: 19, 87: 24, 93: 73, 95: 75};

  void roll() {
    setState(() {
      dice = 1 + rnd.nextInt(6);
      me = min(100, me + dice);
      me = jump[me] ?? me;
      bot = min(100, bot + 1 + rnd.nextInt(6));
      bot = jump[bot] ?? bot;
      if (me >= 100) {
        widget.store.add(400, x: 40);
        me = 1;
        bot = 1;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GamePage(
      title: 'ماروپله',
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Pill(text: 'تو: $me'),
                const SizedBox(width: 8),
                Pill(text: 'حریف: $bot'),
                const Spacer(),
                Pill(text: 'تاس $dice'),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: CustomPaint(painter: BoardPainter(me, bot), child: Container()),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: SizedBox(
              width: 160,
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: orange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                ),
                onPressed: roll,
                child: const Text('انداختن تاس', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BoardPainter extends CustomPainter {
  final int me;
  final int bot;
  BoardPainter(this.me, this.bot);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final cell = min(size.width, size.height) / 10;
    final ox = (size.width - cell * 10) / 2;
    final oy = (size.height - cell * 10) / 2;

    for (int r = 0; r < 10; r++) {
      for (int col = 0; col < 10; col++) {
        paint.color = (r + col).isEven ? cream : const Color(0xffffcf70);
        canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(ox + col * cell, oy + r * cell, cell - 2, cell - 2), const Radius.circular(9)),
          paint,
        );
      }
    }

    void token(int n, Color color) {
      int row = (n - 1) ~/ 10;
      int col = (n - 1) % 10;
      if (row.isOdd) col = 9 - col;
      final x = ox + col * cell + cell / 2;
      final y = oy + (9 - row) * cell + cell / 2;
      paint.color = color;
      paint.style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), cell * .28, paint);
    }

    token(bot, pink);
    token(me, purple);

    paint
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..color = orange;
    canvas.drawLine(Offset(ox + cell * 1.5, oy + cell * 8.5), Offset(ox + cell * 3.5, oy + cell * 6.5), paint);
    canvas.drawLine(Offset(ox + cell * 6.5, oy + cell * 5.5), Offset(ox + cell * 8.5, oy + cell * 2.5), paint);
    paint.color = purple2;
    canvas.drawLine(Offset(ox + cell * 2.5, oy + cell * 1.5), Offset(ox + cell * 1.5, oy + cell * 5.5), paint);
    canvas.drawLine(Offset(ox + cell * 7.5, oy + cell * .8), Offset(ox + cell * 4.5, oy + cell * 4.5), paint);
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) => oldDelegate.me != me || oldDelegate.bot != bot;
}

class MiniGame extends StatefulWidget {
  final String title;
  final String image;
  final Store store;
  const MiniGame({super.key, required this.title, required this.image, required this.store});
  @override
  State<MiniGame> createState() => _MiniGameState();
}

class _MiniGameState extends State<MiniGame> {
  int step = 1;
  int score = 0;

  @override
  Widget build(BuildContext context) {
    return GamePage(
      title: widget.title,
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(18),
          padding: const EdgeInsets.all(18),
          decoration: appBox(cream),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(widget.image, height: 170),
              Text('مرحله $step', style: const TextStyle(fontSize: 24, color: purple, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('حریف آماده شد. گزینه درست را انتخاب کن.', style: TextStyle(color: textColor, fontWeight: FontWeight.bold)),
              for (final i in [0, 1, 2])
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: SizedBox(
                    width: 260,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        setState(() {
                          if (i == 1) {
                            score += 10;
                            widget.store.add(50, x: 5);
                          }
                          step++;
                        });
                      },
                      child: Text(i == 1 ? 'جواب درست' : 'گزینه ${i + 1}'),
                    ),
                  ),
                ),
              Text('امتیاز: $score', style: const TextStyle(color: pink, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ),
    );
  }
}

class FriendPage extends StatefulWidget {
  final Store store;
  const FriendPage({super.key, required this.store});
  @override
  State<FriendPage> createState() => _FriendPageState();
}

class _FriendPageState extends State<FriendPage> {
  String code = '';

  @override
  Widget build(BuildContext context) {
    return GamePage(
      title: 'بازی با دوستان',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Image.asset(Asset.friend),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: appBox(cream),
            child: Column(
              children: [
                const Text('اتاق خصوصی', style: TextStyle(fontSize: 24, color: purple, fontWeight: FontWeight.w900)),
                const Text('یک بازی انتخاب کن، کد اتاق بساز و برای دوستت بفرست.', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [for (final g in ['2048', 'ماروپله', 'حافظه', 'XOX']) Chip(label: Text(g), backgroundColor: gold)],
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: () => setState(() => code = (100000 + Random().nextInt(899999)).toString()),
                  child: const Text('ساخت کد اتاق'),
                ),
                if (code.isNotEmpty) SelectableText(code, style: const TextStyle(fontSize: 32, color: pink, fontWeight: FontWeight.w900)),
                TextField(
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    hintText: 'ورود با کد اتاق',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class InfoPage extends StatelessWidget {
  final String title;
  final String image;
  final String body;
  const InfoPage({super.key, required this.title, required this.image, required this.body});

  @override
  Widget build(BuildContext context) {
    return GamePage(
      title: title,
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(18),
          decoration: appBox(cream),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(image, height: 160),
              Text(body, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.8, color: textColor, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}

class Shop extends StatelessWidget {
  final Store store;
  const Shop({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final packs = [
      'assets/images/asset_54_1b294dc1.webp',
      'assets/images/asset_55_2f47638f.webp',
      'assets/images/asset_56_2d9f93b0.webp',
      'assets/images/asset_57_c06ac75f.webp',
    ];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Header(store),
        Image.asset(Asset.daily),
        const SizedBox(height: 8),
        for (final p in packs)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: ClipRRect(borderRadius: BorderRadius.circular(22), child: Image.asset(p)),
          ),
        const Text('آواتارها', style: TextStyle(color: purple, fontSize: 22, fontWeight: FontWeight.w900)),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (int i = 0; i < Asset.avatars.length; i++)
              GestureDetector(
                onTap: () {
                  if (store.spend(100)) {
                    store.avatar = i;
                    store.save();
                    store.notifyListeners();
                  }
                },
                child: CircleAvatar(
                  radius: 34,
                  backgroundColor: i == store.avatar ? gold : Colors.white,
                  child: CircleAvatar(radius: 30, backgroundImage: AssetImage(Asset.avatars[i])),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class League extends StatelessWidget {
  final Store store;
  const League({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final names = ['برنزی', 'نقره‌ای', 'طلایی', 'الماسی', 'اسطوره'];
    final images = [Asset.bronze, Asset.silver, Asset.goldLeague, Asset.diamond, Asset.legend];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Header(store),
        const Text('لیگ فعلی تو', style: TextStyle(color: purple, fontSize: 24, fontWeight: FontWeight.w900)),
        for (int i = 0; i < 5; i++)
          Container(
            margin: const EdgeInsets.only(top: 10),
            decoration: appBox(cream),
            child: ListTile(
              leading: Image.asset(images[i], width: 70),
              title: Text(names[i], style: const TextStyle(color: purple, fontWeight: FontWeight.w900)),
              subtitle: Text('حداقل XP: ${i * 500}'),
              trailing: store.xp >= i * 500 ? const Icon(Icons.check_circle, color: orange) : null,
            ),
          ),
        const SizedBox(height: 12),
        Image.asset(Asset.league),
      ],
    );
  }
}

class Profile extends StatelessWidget {
  final Store store;
  const Profile({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Header(store),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: appBox(cream),
          child: Column(
            children: [
              CircleAvatar(radius: 54, backgroundImage: AssetImage(Asset.avatars[store.avatar % Asset.avatars.length])),
              const SizedBox(height: 8),
              const Text('بازیکن بازی خونه', style: TextStyle(color: purple, fontSize: 24, fontWeight: FontWeight.w900)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _stat('سکه', store.coins),
                  _stat('XP', store.xp),
                  _stat('برد', store.wins),
                ],
              ),
              const SizedBox(height: 12),
              Image.asset(Asset.support),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  store.coins = 2500;
                  store.xp = 180;
                  store.wins = 0;
                  store.save();
                  store.notifyListeners();
                },
                child: const Text('ریست تست'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _stat(String title, int value) {
    return Column(
      children: [
        Text('$value', style: const TextStyle(color: pink, fontSize: 22, fontWeight: FontWeight.w900)),
        Text(title, style: const TextStyle(color: purple, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
