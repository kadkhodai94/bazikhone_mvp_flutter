import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const BaziKhoneApp());

class BaziKhoneApp extends StatelessWidget {
  const BaziKhoneApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بازی خونه',
      theme: ThemeData(fontFamily: null, useMaterial3: true),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomeShell()),
    );
  }
}

const bg = Color(0xfffff1d9);
const card = Color(0xfffff7ea);
const cream = Color(0xfffff9ef);
const purple = Color(0xff3b075f);
const purple2 = Color(0xff7a0cc6);
const pink = Color(0xffdf2b90);
const orange = Color(0xffff7a18);
const gold = Color(0xffffd867);
const text = Color(0xff2e1447);
const muted = Color(0xff7b688a);

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  int coins = 2500;
  int xp = 120;
  String player = 'بازیکن مهمان';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      coins = p.getInt('coins') ?? 2500;
      xp = p.getInt('xp') ?? 120;
      player = p.getString('player') ?? 'بازیکن مهمان';
    });
  }

  Future<void> addCoins(int value) async {
    final p = await SharedPreferences.getInstance();
    setState(() => coins += value);
    await p.setInt('coins', coins);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(coins: coins, xp: xp, onGame: openGame, onFriend: () => setState(() => tab = 4)),
      ShopPage(coins: coins, onBuy: () => addCoins(500)),
      RankingPage(player: player, coins: coins),
      RewardsPage(onReward: () => addCoins(200)),
      FriendPage(onBack: () => setState(() => tab = 0), onGame: openGame),
      ProfilePage(player: player, coins: coins, xp: xp),
    ];
    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: tab == 4 ? null : Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(26),
          boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 20, offset: Offset(0, 8))],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          navItem('خانه', Icons.home_rounded, 0),
          navItem('فروشگاه', Icons.storefront_rounded, 1),
          navItem('رتبه', Icons.emoji_events_rounded, 2),
          navItem('جوایز', Icons.card_giftcard_rounded, 3),
          navItem('پروفایل', Icons.person_rounded, 5),
        ]),
      ),
    );
  }

  Widget navItem(String label, IconData icon, int index) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: () => setState(() => tab = index),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: tab == index ? const LinearGradient(colors: [purple2, pink]) : null,
        color: tab == index ? null : Colors.transparent,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: tab == index ? Colors.white : purple, size: 23),
        Text(label, style: TextStyle(color: tab == index ? Colors.white : muted, fontSize: 11, fontWeight: FontWeight.w800)),
      ]),
    ),
  );

  void openGame(String title) {
    Widget page;
    if (title == '2048') {
      page = Game2048(onWinCoins: addCoins);
    } else if (title == 'ماروپله') {
      page = SnakeLadderGame(onWinCoins: addCoins);
    } else {
      page = PlaceholderGame(title: title);
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: page)));
  }
}

class HomePage extends StatelessWidget {
  final int coins;
  final int xp;
  final void Function(String) onGame;
  final VoidCallback onFriend;
  const HomePage({super.key, required this.coins, required this.xp, required this.onGame, required this.onFriend});
  @override
  Widget build(BuildContext context) {
    final games = ['دوز', '2048', 'ماروپله', 'حافظه', 'حدس کلمه', 'نقطه‌بازی', 'شطرنج', 'دوز مهره‌ای'];
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 110), children: [
      Row(children: [
        const CircleAvatar(radius: 27, backgroundColor: gold, child: Text('🎮', style: TextStyle(fontSize: 27))),
        const SizedBox(width: 10),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('بازی خونه', style: TextStyle(color: purple, fontSize: 25, fontWeight: FontWeight.w900)),
          Text('رقابت کن، سکه بگیر، بالا برو', style: TextStyle(color: muted, fontWeight: FontWeight.w700)),
        ])),
        coinBadge(coins),
      ]),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: panel(28, gradient: const LinearGradient(colors: [purple, purple2, pink])),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('مسیر امروز', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('XP امروز: $xp  •  جایزه فعال', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)),
          ])),
          const Text('🏆', style: TextStyle(fontSize: 52)),
        ]),
      ),
      const SizedBox(height: 14),
      GestureDetector(
        onTap: onFriend,
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: panel(24, gradient: const LinearGradient(colors: [Color(0xffff9a1b), Color(0xffc51391)])),
          child: const Row(children: [
            Text('👥', style: TextStyle(fontSize: 40)), SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('بازی با دوستان', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
              Text('اتاق بساز، کد بده، رقابت کن', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)),
            ])),
            Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
          ]),
        ),
      ),
      const SizedBox(height: 16),
      const Text('بازی‌ها', style: TextStyle(color: text, fontSize: 21, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: games.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .95),
        itemBuilder: (_, i) => gameCard(games[i], i, () => onGame(games[i])),
      ),
    ]);
  }
}

Widget gameCard(String name, int i, VoidCallback onTap) {
  final icons = ['⭕', '🔢', '🎲', '🧠', '🔤', '⚫', '♟️', '🔶'];
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(26),
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: panel(26),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 58, height: 58, decoration: BoxDecoration(gradient: const LinearGradient(colors: [orange, pink]), borderRadius: BorderRadius.circular(18)), child: Center(child: Text(icons[i], style: const TextStyle(fontSize: 30)))),
        const Spacer(),
        Text(name, style: const TextStyle(color: text, fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('شروع رقابت', style: TextStyle(color: muted, fontWeight: FontWeight.w800)),
      ]),
    ),
  );
}

BoxDecoration panel(double radius, {Gradient? gradient}) => BoxDecoration(
  color: gradient == null ? card : null,
  gradient: gradient,
  borderRadius: BorderRadius.circular(radius),
  border: Border.all(color: Colors.white.withOpacity(.78), width: 1.2),
  boxShadow: const [BoxShadow(color: Color(0x1a521e6e), blurRadius: 24, offset: Offset(0, 12))],
);

Widget coinBadge(int coins) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
  decoration: BoxDecoration(color: cream, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0x22ff7a18))),
  child: Text('🪙 $coins', style: const TextStyle(color: purple, fontWeight: FontWeight.w900)),
);

class FriendPage extends StatefulWidget {
  final VoidCallback onBack;
  final void Function(String) onGame;
  const FriendPage({super.key, required this.onBack, required this.onGame});
  @override
  State<FriendPage> createState() => _FriendPageState();
}
class _FriendPageState extends State<FriendPage> {
  String code = 'KH${Random().nextInt(8999) + 1000}';
  String selected = '2048';
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [IconButton(onPressed: widget.onBack, icon: const Icon(Icons.arrow_back_rounded, color: purple)), const Text('بازی با دوستان', style: TextStyle(color: purple, fontSize: 24, fontWeight: FontWeight.w900))]),
    const SizedBox(height: 16),
    Container(padding: const EdgeInsets.all(18), decoration: panel(28, gradient: const LinearGradient(colors: [purple, pink])), child: Column(children: [
      const Text('اتاق خصوصی', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      Text(code, style: const TextStyle(color: gold, fontSize: 34, letterSpacing: 2, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: ['2048','ماروپله','دوز','حافظه'].map((g)=>ChoiceChip(label: Text(g), selected: selected==g, onSelected: (_)=>setState(()=>selected=g))).toList()),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: primaryButton('کد جدید', ()=>setState(()=>code='KH${Random().nextInt(8999)+1000}'))),
        const SizedBox(width: 10),
        Expanded(child: primaryButton('شروع بازی', ()=>widget.onGame(selected))),
      ]),
    ])),
  ]);
}

Widget primaryButton(String label, VoidCallback onTap) => ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: orange, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))), child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)));

class ShopPage extends StatelessWidget {
  final int coins; final VoidCallback onBuy;
  const ShopPage({super.key, required this.coins, required this.onBuy});
  @override Widget build(BuildContext context)=> simplePage('فروشگاه', 'موجودی: $coins سکه', ['بسته ۵۰۰ سکه','قاب طلایی','آواتار ویژه','راهنمای بازی'], onBuy);
}
class RankingPage extends StatelessWidget { final String player; final int coins; const RankingPage({super.key, required this.player, required this.coins}); @override Widget build(BuildContext context)=> ListView(padding: const EdgeInsets.all(16), children: [pageTitle('رتبه‌بندی'), ...List.generate(10,(i)=>Container(margin: const EdgeInsets.only(bottom:10), padding: const EdgeInsets.all(14), decoration: panel(20), child: Row(children:[Text('#${i+1}', style: const TextStyle(fontWeight: FontWeight.w900,color:purple)), const SizedBox(width:12), Expanded(child: Text(i==3?player:'حریف آماده ${i+1}', style: const TextStyle(fontWeight: FontWeight.w900,color:text))), Text('${i==3?coins:9000-i*530} 🪙')]))]);}
class RewardsPage extends StatelessWidget { final VoidCallback onReward; const RewardsPage({super.key, required this.onReward}); @override Widget build(BuildContext context)=> simplePage('جوایز و مأموریت‌ها','پاداش‌های روزانه و هفتگی', ['ورود روزانه','برد در ۳ بازی','دعوت دوست','تکمیل پروفایل'], onReward);}
class ProfilePage extends StatelessWidget { final String player; final int coins; final int xp; const ProfilePage({super.key, required this.player, required this.coins, required this.xp}); @override Widget build(BuildContext context)=> ListView(padding: const EdgeInsets.all(16), children: [pageTitle('پروفایل'), Container(padding: const EdgeInsets.all(18), decoration: panel(28), child: Column(children:[const CircleAvatar(radius:42,backgroundColor:gold,child:Text('🎮',style:TextStyle(fontSize:38))), const SizedBox(height:12), Text(player, style: const TextStyle(color:text,fontSize:22,fontWeight:FontWeight.w900)), const SizedBox(height:8), Text('سکه: $coins  •  XP: $xp', style: const TextStyle(color:muted,fontWeight:FontWeight.w800))]))]);}

Widget simplePage(String title, String subtitle, List<String> items, VoidCallback action)=>ListView(padding: const EdgeInsets.all(16), children:[pageTitle(title), Text(subtitle, style: const TextStyle(color:muted,fontWeight:FontWeight.w800)), const SizedBox(height:16), ...items.map((e)=>Container(margin: const EdgeInsets.only(bottom:12), padding: const EdgeInsets.all(15), decoration: panel(22), child: Row(children:[const Text('🎁', style: TextStyle(fontSize:30)), const SizedBox(width:12), Expanded(child: Text(e, style: const TextStyle(color:text,fontWeight:FontWeight.w900,fontSize:17))), ElevatedButton(onPressed: action, child: const Text('دریافت'))]))]);
Widget pageTitle(String t)=>Padding(padding: const EdgeInsets.only(bottom:12), child: Text(t, style: const TextStyle(color:purple,fontSize:25,fontWeight:FontWeight.w900)));

class PlaceholderGame extends StatelessWidget { final String title; const PlaceholderGame({super.key, required this.title}); @override Widget build(BuildContext context)=>Scaffold(backgroundColor:bg, appBar: AppBar(backgroundColor:bg,title:Text(title),centerTitle:true), body: Center(child: Container(margin: const EdgeInsets.all(18), padding: const EdgeInsets.all(22), decoration: panel(28), child: Text('منطق بازی $title در مرحله بعد Native می‌شود.', textAlign: TextAlign.center, style: const TextStyle(color:text,fontSize:20,fontWeight:FontWeight.w900)))));}

class Game2048 extends StatefulWidget { final Future<void> Function(int) onWinCoins; const Game2048({super.key, required this.onWinCoins}); @override State<Game2048> createState()=>_Game2048State();}
class _Game2048State extends State<Game2048>{ List<int> b=List.filled(16,0); int score=0; final r=Random(); @override void initState(){super.initState(); reset();} void reset(){b=List.filled(16,0); score=0; add(); add(); setState((){});} void add(){final e=[for(int i=0;i<16;i++) if(b[i]==0)i]; if(e.isNotEmpty)b[e[r.nextInt(e.length)]]=r.nextInt(10)==0?4:2;} void move(int dir){var old=b.join(','); for(int k=0;k<4;k++){var line=<int>[]; for(int j=0;j<4;j++){int idx=dir<2? k*4+j : j*4+k; if(dir==1) idx=k*4+(3-j); if(dir==3) idx=(3-j)*4+k; if(b[idx]!=0)line.add(b[idx]);} for(int i=0;i<line.length-1;i++){if(line[i]==line[i+1]){line[i]*=2; score+=line[i]; line.removeAt(i+1);}} while(line.length<4)line.add(0); for(int j=0;j<4;j++){int idx=dir<2? k*4+j : j*4+k; if(dir==1) idx=k*4+(3-j); if(dir==3) idx=(3-j)*4+k; b[idx]=line[j];}} if(old!=b.join(',')){add(); if(b.contains(2048)) widget.onWinCoins(300); setState((){});} } @override Widget build(BuildContext c)=>Scaffold(backgroundColor:bg, appBar:AppBar(backgroundColor:bg,title:const Text('2048'),centerTitle:true), body:Column(children:[Text('امتیاز: $score', style: const TextStyle(color:purple,fontSize:22,fontWeight:FontWeight.w900)), Expanded(child:GestureDetector(onVerticalDragEnd:(d)=>move((d.primaryVelocity??0)>0?3:2), onHorizontalDragEnd:(d)=>move((d.primaryVelocity??0)>0?1:0), child:Center(child:Container(padding: const EdgeInsets.all(12), decoration: panel(24, gradient: const LinearGradient(colors:[purple,purple2])), child:GridView.builder(shrinkWrap:true,itemCount:16,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,crossAxisSpacing:8,mainAxisSpacing:8), itemBuilder:(_,i)=>Container(decoration:BoxDecoration(color:b[i]==0?Colors.white24:gold,borderRadius:BorderRadius.circular(14)), child:Center(child:Text(b[i]==0?'':'${b[i]}',style:const TextStyle(color:purple,fontSize:24,fontWeight:FontWeight.w900))))))))), Padding(padding: const EdgeInsets.all(16), child: primaryButton('شروع دوباره', reset))]));}

class SnakeLadderGame extends StatefulWidget{ final Future<void> Function(int) onWinCoins; const SnakeLadderGame({super.key, required this.onWinCoins}); @override State<SnakeLadderGame> createState()=>_SnakeLadderGameState();}
class _SnakeLadderGameState extends State<SnakeLadderGame>{int p=1, bot=1, dice=1; final r=Random(); Map<int,int> jump={3:22,8:30,28:84,58:77,75:96,32:10,48:26,62:18,88:24,97:78}; void roll(){setState((){dice=r.nextInt(6)+1; p=min(100,p+dice); p=jump[p]??p; bot=min(100,bot+r.nextInt(6)+1); bot=jump[bot]??bot;}); if(p>=100) widget.onWinCoins(250);} @override Widget build(BuildContext c)=>Scaffold(backgroundColor:bg, appBar:AppBar(backgroundColor:bg,title:const Text('ماروپله'),centerTitle:true), body:ListView(padding: const EdgeInsets.all(16), children:[Container(padding: const EdgeInsets.all(12), decoration: panel(24, gradient: const LinearGradient(colors:[purple,purple2])), child:AspectRatio(aspectRatio:1, child:CustomPaint(painter:BoardPainter(p,bot)))), const SizedBox(height:14), Row(children:[Expanded(child:stat('بازیکن',p)), const SizedBox(width:10), Expanded(child:stat('حریف',bot)), const SizedBox(width:10), Expanded(child:stat('تاس',dice))]), const SizedBox(height:14), primaryButton('انداختن تاس', roll)]));}
Widget stat(String a,int b)=>Container(padding: const EdgeInsets.all(14), decoration: panel(18), child: Column(children:[Text(a,style:const TextStyle(color:muted,fontWeight:FontWeight.w800)),Text('$b',style:const TextStyle(color:purple,fontSize:22,fontWeight:FontWeight.w900))]));
class BoardPainter extends CustomPainter{ final int p,b; BoardPainter(this.p,this.b); @override void paint(Canvas c, Size s){final paint=Paint(); final cell=s.width/10; for(int y=0;y<10;y++){for(int x=0;x<10;x++){paint.color=(x+y).isEven?cream:const Color(0xffffe2b2); final r=RRect.fromRectAndRadius(Rect.fromLTWH(x*cell,y*cell,cell-2,cell-2), const Radius.circular(8)); c.drawRRect(r,paint);}} drawToken(c,s,p,Colors.orange); drawToken(c,s,b,Colors.purple);} void drawToken(Canvas c, Size s, int pos, Color color){final cell=s.width/10; final n=pos-1; final row=9-(n~/10); final col=(n~/10).isEven?n%10:9-n%10; final o=Offset(col*cell+cell/2,row*cell+cell/2); c.drawCircle(o, cell*.27, Paint()..color=color);} @override bool shouldRepaint(covariant BoardPainter old)=>old.p!=p||old.b!=b;}
