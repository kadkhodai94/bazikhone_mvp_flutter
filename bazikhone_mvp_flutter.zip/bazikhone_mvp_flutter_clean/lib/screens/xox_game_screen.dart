import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../state/player_inventory.dart';
import '../theme/app_theme.dart';

class XoxGameScreen extends StatefulWidget {
  const XoxGameScreen({super.key, required this.opponent});

  final PlayerModel opponent;

  @override
  State<XoxGameScreen> createState() => _XoxGameScreenState();
}

class _XoxGameScreenState extends State<XoxGameScreen> {
  final PlayerModel me = const PlayerModel(
    name: 'شما',
    avatarAsset: Assets.avatarUser,
    score: 2450,
    level: 'بازیکن',
  );

  final Random random = Random();
  List<String> board = List.filled(9, '');
  String currentTurn = 'X';
  bool isOpponentThinking = false;
  String resultTitle = '';
  String resultSubtitle = '';
  int myWins = 0;
  int opponentWins = 0;
  int draws = 0;
  int botStyle = 0;
  String? lastMessage;

  bool get isGameOver => resultTitle.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _chooseStarter();
  }

  void _chooseStarter() {
    botStyle = random.nextInt(4);
    currentTurn = random.nextBool() ? 'X' : 'O';
    isOpponentThinking = currentTurn == 'O';
    if (currentTurn == 'O') {
      Future.delayed(const Duration(milliseconds: 650), () {
        if (!mounted || isGameOver || currentTurn != 'O') return;
        _botMove();
      });
    }
  }

  void _onCellTap(int index) {
    if (board[index].isNotEmpty || currentTurn != 'X' || isGameOver || isOpponentThinking) return;

    setState(() => board[index] = 'X');
    if (_finishIfNeeded()) return;

    setState(() {
      currentTurn = 'O';
      isOpponentThinking = true;
    });

    Future.delayed(const Duration(milliseconds: 620), () {
      if (!mounted || isGameOver || currentTurn != 'O') return;
      _botMove();
    });
  }

  void _botMove() {
    final move = _bestBotMove();
    if (move == null) return;

    setState(() {
      board[move] = 'O';
      isOpponentThinking = false;
    });

    if (_finishIfNeeded()) return;
    setState(() => currentTurn = 'X');
  }

  int? _bestBotMove() {
    final empty = <int>[];
    for (var i = 0; i < board.length; i++) {
      if (board[i].isEmpty) empty.add(i);
    }
    if (empty.isEmpty) return null;

    final winMove = _findImmediateMove('O');
    if (winMove != null && random.nextDouble() < 0.92) return winMove;

    final blockMove = _findImmediateMove('X');
    if (blockMove != null && random.nextDouble() < 0.82) return blockMove;

    final moveCount = board.where((cell) => cell.isNotEmpty).length;
    if (moveCount <= 1) {
      final openings = [0, 2, 4, 6, 8, 1, 3, 5, 7].where((i) => board[i].isEmpty).toList();
      return openings[random.nextInt(openings.length)];
    }

    final corners = [0, 2, 6, 8].where((i) => board[i].isEmpty).toList();
    final edges = [1, 3, 5, 7].where((i) => board[i].isEmpty).toList();

    if (botStyle == 0) {
      final pool = [...corners, ...empty, ...edges];
      return pool[random.nextInt(pool.length)];
    }
    if (botStyle == 1) {
      final pool = [...empty, ...empty, ...corners];
      return pool[random.nextInt(pool.length)];
    }
    if (botStyle == 2 && blockMove != null) return blockMove;
    if (botStyle == 3 && random.nextDouble() < 0.38) return empty[random.nextInt(empty.length)];

    if (board[4].isEmpty && random.nextDouble() < 0.55) return 4;
    if (corners.isNotEmpty && random.nextDouble() < 0.65) return corners[random.nextInt(corners.length)];
    return empty[random.nextInt(empty.length)];
  }

  int? _findImmediateMove(String symbol) {
    for (var i = 0; i < board.length; i++) {
      if (board[i].isNotEmpty) continue;
      final copy = [...board];
      copy[i] = symbol;
      if (_winnerOf(copy) == symbol) return i;
    }
    return null;
  }

  bool _finishIfNeeded() {
    final result = _winnerOf(board);
    if (result == null) return false;

    setState(() {
      currentTurn = '';
      isOpponentThinking = false;
      if (result == 'X') {
        myWins++;
        resultTitle = 'بردی! +۳ امتیاز';
        resultSubtitle = 'حریف رو با یک حرکت تمیز بردی.';
      } else if (result == 'O') {
        opponentWins++;
        resultTitle = 'این دست رو باختی';
        resultSubtitle = 'نوبت بعدی می‌تونی جبران کنی.';
      } else {
        draws++;
        resultTitle = 'مساوی شد';
        resultSubtitle = 'بازی نزدیک بود؛ یک دست دیگه؟';
      }
    });
    return true;
  }

  String? _winnerOf(List<String> cells) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (final line in lines) {
      final a = cells[line[0]];
      if (a.isNotEmpty && a == cells[line[1]] && a == cells[line[2]]) return a;
    }
    if (cells.every((cell) => cell.isNotEmpty)) return 'draw';
    return null;
  }

  void _resetGame() {
    setState(() {
      board = List.filled(9, '');
      resultTitle = '';
      resultSubtitle = '';
      isOpponentThinking = false;
      _chooseStarter();
    });
  }

  void _surrender() {
    if (isGameOver) return;
    setState(() {
      opponentWins++;
      currentTurn = '';
      isOpponentThinking = false;
      resultTitle = 'تسلیم شدی';
      resultSubtitle = 'این دست برای ${widget.opponent.name} ثبت شد.';
    });
  }

  @override
  Widget build(BuildContext context) {
    final turnText = isGameOver
        ? resultTitle
        : isOpponentThinking
            ? '${widget.opponent.name} در حال فکر کردنه...'
            : currentTurn == 'X'
                ? 'نوبت شما'
                : 'نوبت ${widget.opponent.name}';

    return Scaffold(
      appBar: AppBar(
        title: const Text('دوز / XOX'),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz_rounded)),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Image.asset(Assets.footerArcade, height: 140, fit: BoxFit.cover),
            ),
            ListView(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 166),
              children: [
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                    children: [
                      Expanded(child: _PlayerPanel(player: me, symbol: 'X', color: AppColors.blue, active: currentTurn == 'X' && !isGameOver)),
                      const SizedBox(width: 12),
                      Expanded(child: _PlayerPanel(player: widget.opponent, symbol: 'O', color: AppColors.pink, active: currentTurn == 'O' && !isGameOver)),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                _TurnPill(text: turnText, isOpponentThinking: isOpponentThinking),
                if (lastMessage != null) ...[
                  const SizedBox(height: 10),
                  _SentMessageBubble(text: lastMessage!),
                ],
                const SizedBox(height: 20),
                _GameBoard(cells: board, onTap: _onCellTap),
                if (resultTitle.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  _ResultCard(title: resultTitle, subtitle: resultSubtitle),
                ],
                const SizedBox(height: 18),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                    children: [
                      _ChatButton(onTap: () => _showMessages(context)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: _SurrenderButton(
                          text: isGameOver ? 'بازی دوباره' : 'تسلیم شدن',
                          icon: isGameOver ? Icons.refresh_rounded : null,
                          onTap: isGameOver ? _resetGame : _surrender,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text(
                    'برد: $myWins   مساوی: $draws   باخت: $opponentWins',
                    style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMessages(BuildContext context) {
    final messages = PlayerInventory.instance.ownedMessages;
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        child: Wrap(
          alignment: WrapAlignment.center,
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final item in messages)
              _MessageChip(
                item.text,
                onTap: () {
                  Navigator.pop(context);
                  setState(() => lastMessage = item.text);
                  Future.delayed(const Duration(seconds: 2), () {
                    if (mounted && lastMessage == item.text) setState(() => lastMessage = null);
                  });
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _PlayerPanel extends StatelessWidget {
  const _PlayerPanel({required this.player, required this.symbol, required this.color, required this.active});

  final PlayerModel player;
  final String symbol;
  final Color color;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final inventory = PlayerInventory.instance;
    return AnimatedBuilder(
      animation: inventory,
      builder: (context, _) {
        final isMe = symbol == 'X';
        final avatar = inventory.selectedAvatar;
        final frame = inventory.selectedFrame;
        final emoji = isMe ? avatar.emoji : '😎';
        final avatarColors = isMe ? avatar.colors : const [Color(0xFFFFEEF3), Color(0xFFEAF6FF)];
        final frameColors = isMe ? frame.colors : [color.withOpacity(0.75), color.withOpacity(0.28)];
        return Container(
          height: 96,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: active ? color : color.withOpacity(0.34), width: active ? 2 : 1.4),
            boxShadow: active ? [BoxShadow(color: color.withOpacity(0.12), blurRadius: 18, offset: const Offset(0, 8))] : const [],
          ),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Container(
                  width: 62,
                  height: 62,
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: frameColors)),
                  child: Container(
                    decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: avatarColors)),
                    alignment: Alignment.center,
                    child: Text(emoji, style: const TextStyle(fontSize: 30)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                      const SizedBox(height: 2),
                      Text(symbol, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 30, height: 1)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _SentMessageBubble extends StatelessWidget {
  const _SentMessageBubble({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF4EC),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        child: Text(text, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 14)),
      ),
    );
  }
}

class _TurnPill extends StatelessWidget {
  const _TurnPill({required this.text, required this.isOpponentThinking});

  final String text;
  final bool isOpponentThinking;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 13, height: 13, decoration: BoxDecoration(color: isOpponentThinking ? AppColors.pink : AppColors.blue, shape: BoxShape.circle)),
            const SizedBox(width: 9),
            Text(text, style: const TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class _GameBoard extends StatelessWidget {
  const _GameBoard({required this.cells, required this.onTap});

  final List<String> cells;
  final void Function(int index) onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(34),
        boxShadow: const [AppShadows.card],
        border: Border.all(color: AppColors.border),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: AspectRatio(
          aspectRatio: 1,
          child: GridView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
            itemCount: 9,
            itemBuilder: (context, index) {
              return _BoardCell(symbol: cells[index], onTap: () => onTap(index));
            },
          ),
        ),
      ),
    );
  }
}

class _BoardCell extends StatelessWidget {
  const _BoardCell({required this.symbol, required this.onTap});

  final String symbol;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = symbol == 'X' ? AppColors.blue : AppColors.pink;
    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: symbol == 'X'
              ? AppColors.blue.withOpacity(0.06)
              : symbol == 'O'
                  ? AppColors.pink.withOpacity(0.06)
                  : AppColors.surface,
          border: Border.all(color: const Color(0xFFEBDCCA), width: 0.7),
        ),
        alignment: Alignment.center,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 180),
          scale: symbol.isEmpty ? 0.4 : 1,
          child: Text(
            symbol,
            style: TextStyle(
              color: color,
              fontSize: 58,
              fontWeight: FontWeight.w900,
              shadows: [Shadow(color: color.withOpacity(0.33), blurRadius: 14)],
            ),
          ),
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(colors: [Color(0xFFFFE7DA), Color(0xFFEDE8FF)]),
      ),
      child: Row(
        children: [
          const Icon(Icons.emoji_events_rounded, color: AppColors.yellow, size: 38),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 20)),
                const SizedBox(height: 5),
                Text(subtitle, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatButton extends StatelessWidget {
  const _ChatButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        width: 62,
        height: 62,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        child: const Icon(Icons.chat_bubble_outline_rounded, color: AppColors.text, size: 27),
      ),
    );
  }
}

class _SurrenderButton extends StatelessWidget {
  const _SurrenderButton({required this.text, this.icon, required this.onTap});

  final String text;
  final IconData? icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(25),
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: const LinearGradient(colors: [Color(0xFFFF5F65), Color(0xFFFF8270)]),
          boxShadow: [BoxShadow(color: AppColors.pink.withOpacity(0.22), blurRadius: 18, offset: const Offset(0, 8))],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, color: Colors.white, size: 23),
              const SizedBox(width: 8),
            ],
            Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
          ],
        ),
      ),
    );
  }
}

class _MessageChip extends StatelessWidget {
  const _MessageChip(this.text, {required this.onTap});

  final String text;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      onPressed: onTap,
      label: Text(text, style: const TextStyle(fontWeight: FontWeight.w900)),
      backgroundColor: const Color(0xFFFFF4EC),
      side: const BorderSide(color: AppColors.border),
    );
  }
}
