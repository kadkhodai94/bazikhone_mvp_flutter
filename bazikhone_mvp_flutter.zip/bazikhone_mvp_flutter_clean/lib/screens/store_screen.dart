import 'package:flutter/material.dart';

import '../state/player_inventory.dart';
import '../theme/app_theme.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final inventory = PlayerInventory.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('فروشگاه')),
      body: SafeArea(
        child: AnimatedBuilder(
          animation: inventory,
          builder: (context, _) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
              children: [
                _StoreHero(coins: inventory.coins),
                const SizedBox(height: 18),
                const _SectionTitle('آواتارهای اختصاصی', 'برای نمایش روی پروفایل و داخل بازی'),
                const SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: PlayerInventory.avatars.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.84,
                  ),
                  itemBuilder: (context, index) {
                    final item = PlayerInventory.avatars[index];
                    return _AvatarStoreTile(
                      item: item,
                      owned: inventory.ownsAvatar(item.id),
                      selected: inventory.selectedAvatarId == item.id,
                      onTap: () => _handleAvatar(context, inventory, item),
                    );
                  },
                ),
                const SizedBox(height: 22),
                const _SectionTitle('قاب پروفایل', 'قاب‌ها روی آواتار شما نمایش داده می‌شوند'),
                const SizedBox(height: 10),
                SizedBox(
                  height: 136,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    reverse: true,
                    physics: const BouncingScrollPhysics(),
                    itemCount: PlayerInventory.frames.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, index) {
                      final item = PlayerInventory.frames[index];
                      return _FrameStoreTile(
                        item: item,
                        owned: inventory.ownsFrame(item.id),
                        selected: inventory.selectedFrameId == item.id,
                        onTap: () => _handleFrame(context, inventory, item),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 22),
                const _SectionTitle('پیام‌های داخل بازی', 'پیام آماده امن و سریع، بدون چت آزاد'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    for (final item in PlayerInventory.messages)
                      _MessageStoreChip(
                        item: item,
                        owned: inventory.ownsMessage(item.id),
                        onTap: () => _handleMessage(context, inventory, item),
                      ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  static Future<void> _handleAvatar(BuildContext context, PlayerInventory inventory, AvatarItem item) async {
    final ok = await inventory.buyOrSelectAvatar(item);
    if (!context.mounted) return;
    _toast(context, ok ? '${item.name} انتخاب شد' : 'سکه کافی نداری');
  }

  static Future<void> _handleFrame(BuildContext context, PlayerInventory inventory, FrameItem item) async {
    final ok = await inventory.buyOrSelectFrame(item);
    if (!context.mounted) return;
    _toast(context, ok ? 'قاب ${item.name} فعال شد' : 'سکه کافی نداری');
  }

  static Future<void> _handleMessage(BuildContext context, PlayerInventory inventory, MessageItem item) async {
    final ok = await inventory.buyMessage(item);
    if (!context.mounted) return;
    _toast(context, ok ? 'پیام اضافه شد' : 'سکه کافی نداری');
  }

  static void _toast(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _StoreHero extends StatelessWidget {
  const _StoreHero({required this.coins});
  final int coins;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        gradient: const LinearGradient(colors: [Color(0xFFFFE8D6), Color(0xFFEDE8FF)]),
        boxShadow: const [AppShadows.soft],
      ),
      child: Row(
        children: [
          Container(
            width: 68,
            height: 68,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.75), borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.storefront_rounded, color: AppColors.primary, size: 40),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('فروشگاه آیتم‌ها', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 24)),
                const SizedBox(height: 7),
                Text('سکه فعلی: ${toPersianDigits(coins)}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
          ),
          const Icon(Icons.stars_rounded, color: AppColors.yellow, size: 38),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.title, this.subtitle);
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 22)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
      ],
    );
  }
}

class _AvatarStoreTile extends StatelessWidget {
  const _AvatarStoreTile({required this.item, required this.owned, required this.selected, required this.onTap});
  final AvatarItem item;
  final bool owned;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: selected ? AppColors.purple : AppColors.border, width: selected ? 2 : 1),
          boxShadow: const [AppShadows.soft],
        ),
        child: Column(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: item.colors)),
                alignment: Alignment.center,
                child: Text(item.emoji, style: const TextStyle(fontSize: 32)),
              ),
            ),
            const SizedBox(height: 7),
            Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 13)),
            const SizedBox(height: 3),
            Text(selected ? 'فعال' : owned ? 'انتخاب' : '${toPersianDigits(item.price)} سکه', style: TextStyle(color: selected ? AppColors.purple : owned ? AppColors.primary : AppColors.muted, fontWeight: FontWeight.w900, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _FrameStoreTile extends StatelessWidget {
  const _FrameStoreTile({required this.item, required this.owned, required this.selected, required this.onTap});
  final FrameItem item;
  final bool owned;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(26),
      child: Container(
        width: 130,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: selected ? item.colors.last : AppColors.border, width: selected ? 2 : 1),
          boxShadow: const [AppShadows.soft],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 58,
              height: 58,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: item.colors)),
              child: Container(decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.surface), alignment: Alignment.center, child: const Text('🙂', style: TextStyle(fontSize: 25))),
            ),
            const SizedBox(height: 9),
            Text(item.name, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 14)),
            const SizedBox(height: 3),
            Text(selected ? 'فعال' : owned ? 'انتخاب' : '${toPersianDigits(item.price)} سکه', style: TextStyle(color: selected ? AppColors.purple : owned ? AppColors.primary : AppColors.muted, fontWeight: FontWeight.w900, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _MessageStoreChip extends StatelessWidget {
  const _MessageStoreChip({required this.item, required this.owned, required this.onTap});
  final MessageItem item;
  final bool owned;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      onPressed: onTap,
      label: Text(owned ? item.text : '${item.text}  |  ${toPersianDigits(item.price)}', style: const TextStyle(fontWeight: FontWeight.w900)),
      avatar: Icon(owned ? Icons.check_circle_rounded : Icons.lock_rounded, size: 18, color: owned ? const Color(0xFF20A871) : AppColors.primary),
      backgroundColor: owned ? const Color(0xFFEFFFF6) : const Color(0xFFFFF4EC),
      side: BorderSide(color: owned ? const Color(0xFFBCEBD5) : AppColors.border),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
    );
  }
}
