import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = const [
      _Leader(1, 'آرمان', '😎', 2560),
      _Leader(2, 'سارا', '🙂', 2180),
      _Leader(3, 'مهدی', '🤓', 1930),
      _Leader(4, 'نیما', '🧢', 1640),
      _Leader(5, 'شما', '🙂', 1240, isMe: true),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('رتبه‌بندی')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                gradient: const LinearGradient(colors: [Color(0xFFFFE8D6), Color(0xFFEDE8FF)]),
                boxShadow: const [AppShadows.soft],
              ),
              child: Row(
                children: const [
                  Icon(Icons.emoji_events_rounded, color: AppColors.yellow, size: 58),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('برترین‌های بازی‌خونه', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 24)),
                        SizedBox(height: 8),
                        Text('رتبه‌بندی نمونه نسخه چهارم MVP', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const _Tabs(),
            const SizedBox(height: 16),
            for (final row in rows) ...[
              _LeaderboardRow(row),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }
}

class _Tabs extends StatelessWidget {
  const _Tabs();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 64,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border),
        boxShadow: const [AppShadows.soft],
      ),
      child: Row(
        children: const [
          Expanded(child: _TabItem('امروز', true)),
          Expanded(child: _TabItem('هفته', false)),
          Expanded(child: _TabItem('ماه', false)),
        ],
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  const _TabItem(this.text, this.active);
  final String text;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: active ? AppColors.primary : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(color: active ? Colors.white : AppColors.muted, fontWeight: FontWeight.w900, fontSize: 16),
      ),
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  const _LeaderboardRow(this.item);
  final _Leader item;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 78,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(
        color: item.isMe ? const Color(0xFFFFEEE8) : AppColors.surface,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: item.isMe ? const Color(0xFFFFD3C4) : AppColors.border),
        boxShadow: const [AppShadows.soft],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: item.rank == 1
                  ? const Color(0xFFFFF5DA)
                  : item.rank == 2
                      ? const Color(0xFFEFEAFF)
                      : const Color(0xFFFFEFE6),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text('${item.rank}', style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 18)),
          ),
          const SizedBox(width: 14),
          Text(item.avatar, style: const TextStyle(fontSize: 27)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                if (item.isMe) const Text('جایگاه فعلی شما', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 12)),
              ],
            ),
          ),
          Text('${item.score}', style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(width: 6),
          const Icon(Icons.star_rounded, color: AppColors.yellow, size: 27),
        ],
      ),
    );
  }
}

class _Leader {
  const _Leader(this.rank, this.name, this.avatar, this.score, {this.isMe = false});
  final int rank;
  final String name;
  final String avatar;
  final int score;
  final bool isMe;
}
