import 'package:flutter/material.dart';

import '../state/player_inventory.dart';
import '../theme/app_theme.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';
import 'store_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
          child: Column(
            children: [
              const _TopBar(),
              const SizedBox(height: 12),
              const _HeroBanner(),
              const SizedBox(height: 18),
              Row(
                children: [
                  Text(
                    'بازی های نوستالژی',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 26, height: 1),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF0E7),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: const Text(
                      'نسخه آزمایشی',
                      style: TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.w900),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverGrid(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 1.12,
                      ),
                      delegate: SliverChildListDelegate.fixed([
                        _GameTile(
                          title: 'دوز / XOX',
                          subtitle: 'شروع سریع',
                          icon: const _XoxIcon(),
                          isActive: true,
                          onTap: () => _startQuickGame(context),
                        ),
                        const _GameTile(
                          title: 'سنگ کاغذ قیچی',
                          subtitle: 'به‌زودی',
                          icon: _RpsIcon(),
                        ),
                        const _GameTile(
                          title: 'چهار در یک ردیف',
                          subtitle: 'به‌زودی',
                          icon: _ConnectIcon(),
                        ),
                        const _GameTile(
                          title: 'حدس کلمه',
                          subtitle: 'به‌زودی',
                          icon: _QuestionIcon(),
                        ),
                      ]),
                    ),
                    const SliverToBoxAdapter(child: SizedBox(height: 14)),
                    SliverToBoxAdapter(
                      child: Row(
                        children: [
                          Expanded(
                            child: _ActionTile(
                              title: 'بازی سریع',
                              icon: Icons.bolt_rounded,
                              color: const Color(0xFFFFF4D7),
                              iconColor: AppColors.primary,
                              onTap: () => _startQuickGame(context),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _ActionTile(
                              title: 'مسابقات',
                              icon: Icons.emoji_events_rounded,
                              color: const Color(0xFFF2ECFF),
                              iconColor: AppColors.yellow,
                              onTap: () => _comingSoon(context, 'مسابقات'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _ActionTile(
                              title: 'اشتراک ویژه',
                              icon: Icons.workspace_premium_rounded,
                              color: const Color(0xFFFFEAF5),
                              iconColor: AppColors.yellow,
                              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen())),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SliverToBoxAdapter(child: SizedBox(height: 14)),
                    SliverToBoxAdapter(
                      child: Row(
                        children: [
                          Expanded(
                            child: _WideButton(
                              text: 'رتبه‌بندی',
                              icon: Icons.leaderboard_rounded,
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _WideButton(
                              text: 'فروشگاه',
                              icon: Icons.storefront_rounded,
                              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen())),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SliverToBoxAdapter(child: SizedBox(height: 14)),
                    const SliverToBoxAdapter(child: _MissionCard()),
                    const SliverToBoxAdapter(child: SizedBox(height: 24)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen()));
  }

  static void _comingSoon(BuildContext context, String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$title در نسخه بعدی فعال می‌شود.')),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    final inventory = PlayerInventory.instance;
    return AnimatedBuilder(
      animation: inventory,
      builder: (context, _) {
        final avatar = inventory.selectedAvatar;
        final frame = inventory.selectedFrame;
        return Directionality(
          textDirection: TextDirection.ltr,
          child: SizedBox(
            height: 76,
            child: Row(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 66,
                      height: 66,
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: frame.colors),
                        boxShadow: const [AppShadows.soft],
                      ),
                      child: Container(
                        decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: avatar.colors)),
                        alignment: Alignment.center,
                        child: Text(avatar.emoji, style: const TextStyle(fontSize: 32)),
                      ),
                    ),
                    Positioned(
                      right: -8,
                      bottom: 5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: AppColors.purple,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: const [AppShadows.soft],
                        ),
                        child: const Text('23', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                Container(
                  height: 52,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: AppColors.border),
                    boxShadow: const [AppShadows.soft],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.stars_rounded, color: AppColors.yellow, size: 28),
                      const SizedBox(width: 10),
                      Text(toPersianDigits(inventory.coins), style: const TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
                const Spacer(),
                Container(
                  width: 52,
                  height: 52,
                  alignment: Alignment.center,
                  child: IconButton(
                    iconSize: 34,
                    color: const Color(0xFF5E5E67),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen())),
                    icon: const Icon(Icons.settings_outlined),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _HeroBanner extends StatelessWidget {
  const _HeroBanner();

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 796 / 473,
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(26), boxShadow: const [AppShadows.card]),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: Image.asset(Assets.homeHero, fit: BoxFit.cover, filterQuality: FilterQuality.high),
        ),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  const _GameTile({required this.title, required this.icon, required this.subtitle, this.isActive = false, this.onTap});

  final String title;
  final Widget icon;
  final String subtitle;
  final bool isActive;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(30),
        child: Ink(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: isActive ? AppColors.blue.withOpacity(0.55) : AppColors.border, width: isActive ? 1.7 : 1),
            boxShadow: const [AppShadows.soft],
          ),
          child: Stack(
            children: [
              Positioned(
                top: 14,
                right: 14,
                child: isActive
                    ? Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(color: const Color(0xFFE6FFF4), borderRadius: BorderRadius.circular(99)),
                        child: const Text('فعال', style: TextStyle(color: Color(0xFF20A871), fontWeight: FontWeight.w900, fontSize: 12)),
                      )
                    : const SizedBox.shrink(),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 18, 12, 12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Expanded(child: Center(child: icon)),
                    const SizedBox(height: 8),
                    Text(title, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    Text(subtitle, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _XoxIcon extends StatelessWidget {
  const _XoxIcon();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          _GlowText('X', color: AppColors.blue, size: 48),
          SizedBox(width: 10),
          _GlowText('O', color: AppColors.pink, size: 48),
        ],
      ),
    );
  }
}

class _GlowText extends StatelessWidget {
  const _GlowText(this.text, {required this.color, required this.size});
  final String text;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w900, height: 1, shadows: [Shadow(color: color.withOpacity(0.35), blurRadius: 12)]),
    );
  }
}

class _RpsIcon extends StatelessWidget {
  const _RpsIcon();

  @override
  Widget build(BuildContext context) {
    return const FittedBox(
      fit: BoxFit.scaleDown,
      child: Text('✊ ✌️ ✌️', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 34, height: 1)),
    );
  }
}

class _ConnectIcon extends StatelessWidget {
  const _ConnectIcon();

  @override
  Widget build(BuildContext context) {
    const colors = [AppColors.pink, AppColors.blue, AppColors.blue, AppColors.pink, AppColors.blue, AppColors.blue, AppColors.pink, Color(0xFFB7B9C8), AppColors.yellow, AppColors.yellow, AppColors.pink, AppColors.yellow];
    return Container(
      width: 86,
      height: 58,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFD8E2F0)),
      ),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 12,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemBuilder: (context, index) => DecoratedBox(
          decoration: BoxDecoration(shape: BoxShape.circle, color: colors[index], boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 3)]),
        ),
      ),
    );
  }
}

class _QuestionIcon extends StatelessWidget {
  const _QuestionIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 64,
      height: 56,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(17),
        gradient: const LinearGradient(colors: [Color(0xFFFFD760), Color(0xFFFFB13F)]),
        boxShadow: const [BoxShadow(color: Color(0x33FF9800), blurRadius: 12, offset: Offset(0, 6))],
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: const Text('?', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.title, required this.icon, required this.color, required this.iconColor, this.onTap});

  final String title;
  final IconData icon;
  final Color color;
  final Color iconColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(26),
      child: Container(
        height: 108,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: Colors.white.withOpacity(0.9)),
          boxShadow: const [AppShadows.soft],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor, size: 40),
            const SizedBox(height: 9),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 15)),
          ],
        ),
      ),
    );
  }
}

class _WideButton extends StatelessWidget {
  const _WideButton({required this.text, required this.icon, required this.onTap});

  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.text, size: 24),
            const SizedBox(width: 8),
            Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: AppColors.text)),
          ],
        ),
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  const _MissionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(26), border: Border.all(color: AppColors.border), boxShadow: const [AppShadows.soft]),
      child: Row(
        children: const [
          Icon(Icons.local_fire_department_rounded, color: AppColors.primary, size: 34),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ماموریت امروز', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                SizedBox(height: 5),
                Text('۳ دست دوز بازی کن و ۵۰ سکه بگیر', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
              ],
            ),
          ),
          Icon(Icons.chevron_left_rounded, color: AppColors.muted, size: 28),
        ],
      ),
    );
  }
}
