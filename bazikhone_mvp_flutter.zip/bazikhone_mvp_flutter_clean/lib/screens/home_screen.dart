import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
          child: Column(
            children: [
              const _TopBar(),
              const SizedBox(height: 14),
              const _HeroBanner(),
              const SizedBox(height: 18),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'بازی های نوستالژی',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 25),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(bottom: 22),
                  children: [
                    GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: 1.18,
                      children: [
                        _GameTile(
                          title: 'دوز / XOX',
                          icon: const _XoxIcon(),
                          subtitle: 'شروع سریع',
                          isActive: true,
                          onTap: () => _startQuickGame(context),
                        ),
                        const _GameTile(
                          title: 'سنگ کاغذ قیچی',
                          icon: _EmojiIcon('✊ ✌️ ✌️'),
                          subtitle: 'به‌زودی',
                        ),
                        const _GameTile(
                          title: 'چهار در یک ردیف',
                          icon: _ConnectIcon(),
                          subtitle: 'به‌زودی',
                        ),
                        const _GameTile(
                          title: 'حدس کلمه',
                          icon: _QuestionIcon(),
                          subtitle: 'به‌زودی',
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _ActionTile(
                            title: 'بازی سریع',
                            icon: Icons.bolt_rounded,
                            color: const Color(0xFFFFF4D7),
                            iconColor: AppColors.primary,
                            onTap: () => _startQuickGame(context),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _ActionTile(
                            title: 'مسابقات',
                            icon: Icons.emoji_events_rounded,
                            color: const Color(0xFFF3EEFF),
                            iconColor: AppColors.yellow,
                            onTap: () => _comingSoon(context, 'مسابقات'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _ActionTile(
                            title: 'اشتراک ویژه',
                            icon: Icons.workspace_premium_rounded,
                            color: const Color(0xFFFFECF5),
                            iconColor: AppColors.yellow,
                            onTap: () => _comingSoon(context, 'اشتراک ویژه'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _WideButton(
                            text: 'رتبه‌بندی',
                            icon: Icons.leaderboard_rounded,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _WideButton(
                            text: 'فروشگاه',
                            icon: Icons.storefront_rounded,
                            onTap: () => _comingSoon(context, 'فروشگاه آیتم‌ها'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const _MissionCard(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen()));
  }

  void _comingSoon(BuildContext context, String title) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title در نسخه بعدی فعال می‌شود.')));
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 68,
                height: 68,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.purple.withOpacity(0.78), width: 2.4),
                ),
                child: ClipOval(
                  child: Image.asset(
                    Assets.avatarUser,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.high,
                  ),
                ),
              ),
              Positioned(
                right: -10,
                bottom: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                  decoration: BoxDecoration(
                    color: AppColors.purple,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [AppShadows.soft],
                  ),
                  child: const Text('23', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 23, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.border),
              boxShadow: const [AppShadows.soft],
            ),
            child: Row(
              children: const [
                Icon(Icons.stars_rounded, color: AppColors.yellow, size: 28),
                SizedBox(width: 11),
                Text('۲,۴۵۰', style: TextStyle(color: AppColors.text, fontSize: 20, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          const Spacer(),
          IconButton(
            iconSize: 34,
            color: const Color(0xFF60606A),
            onPressed: () {},
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
    );
  }
}

class _HeroBanner extends StatelessWidget {
  const _HeroBanner();

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 796 / 473,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          boxShadow: const [AppShadows.soft],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: Image.asset(
            Assets.homeHero,
            fit: BoxFit.cover,
            filterQuality: FilterQuality.high,
          ),
        ),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  const _GameTile({
    required this.title,
    required this.icon,
    required this.subtitle,
    this.isActive = false,
    this.onTap,
  });

  final String title;
  final Widget icon;
  final String subtitle;
  final bool isActive;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(28),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(28),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: isActive ? AppColors.blue.withOpacity(0.38) : AppColors.border, width: isActive ? 1.6 : 1),
            boxShadow: const [AppShadows.soft],
            color: AppColors.surface,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: isActive
                    ? Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(color: const Color(0xFFE6FFF4), borderRadius: BorderRadius.circular(99)),
                        child: const Text('فعال', style: TextStyle(color: Color(0xFF20A871), fontWeight: FontWeight.w900, fontSize: 12)),
                      )
                    : const SizedBox(height: 26),
              ),
              Expanded(child: Center(child: icon)),
              Text(
                title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _XoxIcon extends StatelessWidget {
  const _XoxIcon();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Text('X', style: TextStyle(color: AppColors.blue, fontSize: 42, fontWeight: FontWeight.w900, shadows: [Shadow(color: Color(0x552791F4), blurRadius: 10)])),
          SizedBox(width: 8),
          Text('O', style: TextStyle(color: AppColors.pink, fontSize: 42, fontWeight: FontWeight.w900, shadows: [Shadow(color: Color(0x55FF4F86), blurRadius: 10)])),
        ],
      ),
    );
  }
}

class _EmojiIcon extends StatelessWidget {
  const _EmojiIcon(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(text, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 36, height: 1)),
    );
  }
}

class _ConnectIcon extends StatelessWidget {
  const _ConnectIcon();

  @override
  Widget build(BuildContext context) {
    const colors = [AppColors.pink, AppColors.blue, AppColors.blue, AppColors.pink, AppColors.blue, AppColors.pink, Color(0xFFB7B9C8), AppColors.yellow, AppColors.yellow, AppColors.pink];
    return Container(
      width: 74,
      height: 50,
      padding: const EdgeInsets.all(7),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAFF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFD8E2F0)),
      ),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 10,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemBuilder: (context, index) => DecoratedBox(
          decoration: BoxDecoration(shape: BoxShape.circle, color: colors[index], boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 3)]),
        ),
      ),
    );
  }
}

class _QuestionIcon extends StatelessWidget {
  const _QuestionIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 58,
      height: 58,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(colors: [Color(0xFFFFD45B), Color(0xFFFFA726)]),
        boxShadow: const [BoxShadow(color: Color(0x33FF9800), blurRadius: 12, offset: Offset(0, 6))],
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: const Text('?', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.title, required this.icon, required this.color, required this.iconColor, this.onTap});

  final String title;
  final IconData icon;
  final Color color;
  final Color iconColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 110,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.9)),
          boxShadow: const [AppShadows.soft],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor, size: 38),
            const SizedBox(height: 10),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 15)),
          ],
        ),
      ),
    );
  }
}

class _WideButton extends StatelessWidget {
  const _WideButton({required this.text, required this.icon, required this.onTap});

  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.text, size: 24),
            const SizedBox(width: 8),
            Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: AppColors.text)),
          ],
        ),
      ),
    );
  }
}

class _MissionCard extends StatelessWidget {
  const _MissionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: const [AppShadows.soft],
      ),
      child: Row(
        children: const [
          Icon(Icons.local_fire_department_rounded, color: AppColors.primary, size: 34),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ماموریت امروز', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 17)),
                SizedBox(height: 5),
                Text('۳ دست دوز بازی کن و ۵۰ سکه بگیر', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
              ],
            ),
          ),
          Icon(Icons.chevron_left_rounded, color: AppColors.muted, size: 28),
        ],
      ),
    );
  }
}
