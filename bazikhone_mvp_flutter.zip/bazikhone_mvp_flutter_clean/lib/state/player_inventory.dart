import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_theme.dart';

class AvatarItem {
  const AvatarItem({
    required this.id,
    required this.name,
    required this.emoji,
    required this.price,
    required this.colors,
  });

  final String id;
  final String name;
  final String emoji;
  final int price;
  final List<Color> colors;
}

class FrameItem {
  const FrameItem({
    required this.id,
    required this.name,
    required this.price,
    required this.colors,
  });

  final String id;
  final String name;
  final int price;
  final List<Color> colors;
}

class MessageItem {
  const MessageItem({required this.id, required this.text, required this.price});

  final String id;
  final String text;
  final int price;
}

class PlayerInventory extends ChangeNotifier {
  PlayerInventory._();

  static final PlayerInventory instance = PlayerInventory._();

  static const List<AvatarItem> avatars = [
    AvatarItem(id: 'smile', name: 'کلاسیک', emoji: '🙂', price: 0, colors: [Color(0xFFEAF6FF), Color(0xFFFFEEF3)]),
    AvatarItem(id: 'cool', name: 'خفن', emoji: '😎', price: 120, colors: [Color(0xFFFFF2C8), Color(0xFFEDE8FF)]),
    AvatarItem(id: 'gamer', name: 'گیمر', emoji: '🎮', price: 180, colors: [Color(0xFFE6F3FF), Color(0xFFEDE8FF)]),
    AvatarItem(id: 'ninja', name: 'نینجا', emoji: '🥷', price: 220, colors: [Color(0xFFE8EAF2), Color(0xFFFFE7DA)]),
    AvatarItem(id: 'robot', name: 'رباتیک', emoji: '🤖', price: 260, colors: [Color(0xFFE8FFF4), Color(0xFFEAF6FF)]),
    AvatarItem(id: 'king', name: 'قهرمان', emoji: '👑', price: 420, colors: [Color(0xFFFFF1BE), Color(0xFFFFE4EF)]),
  ];

  static const List<FrameItem> frames = [
    FrameItem(id: 'soft', name: 'ساده', price: 0, colors: [AppColors.purple, AppColors.blue]),
    FrameItem(id: 'gold', name: 'طلایی', price: 140, colors: [Color(0xFFFFC53D), Color(0xFFFF8A3D)]),
    FrameItem(id: 'neon', name: 'نئونی', price: 220, colors: [AppColors.purple, AppColors.pink]),
    FrameItem(id: 'pixel', name: 'پیکسلی', price: 280, colors: [AppColors.blue, Color(0xFF00C2A8)]),
    FrameItem(id: 'vip', name: 'VIP', price: 450, colors: [Color(0xFFFFB23D), AppColors.pink]),
  ];

  static const List<MessageItem> messages = [
    MessageItem(id: 'good', text: 'بازی خوبی بود 👏', price: 0),
    MessageItem(id: 'move', text: 'حرکت قشنگی زدی 😄', price: 0),
    MessageItem(id: 'win', text: 'این یکی رو می‌برم 🔥', price: 0),
    MessageItem(id: 'again', text: 'دوباره بازی کنیم؟', price: 0),
    MessageItem(id: 'thanks', text: 'دمت گرم', price: 0),
    MessageItem(id: 'lucky', text: 'شانسی بود 😅', price: 80),
    MessageItem(id: 'watch', text: 'حواست باشه 😎', price: 110),
    MessageItem(id: 'pro', text: 'حریف قدری هستی 💪', price: 130),
    MessageItem(id: 'fast', text: 'سریع بازی کن ⏱️', price: 150),
    MessageItem(id: 'revenge', text: 'دست بعد جبران می‌کنم ⚡', price: 180),
  ];

  int coins = 2450;
  String selectedAvatarId = 'smile';
  String selectedFrameId = 'soft';
  final Set<String> ownedAvatarIds = {'smile'};
  final Set<String> ownedFrameIds = {'soft'};
  final Set<String> ownedMessageIds = {'good', 'move', 'win', 'again', 'thanks'};

  AvatarItem get selectedAvatar => avatars.firstWhere((item) => item.id == selectedAvatarId, orElse: () => avatars.first);
  FrameItem get selectedFrame => frames.firstWhere((item) => item.id == selectedFrameId, orElse: () => frames.first);
  List<MessageItem> get ownedMessages => messages.where((item) => ownedMessageIds.contains(item.id)).toList();

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    coins = prefs.getInt('coins') ?? coins;
    selectedAvatarId = prefs.getString('selectedAvatarId') ?? selectedAvatarId;
    selectedFrameId = prefs.getString('selectedFrameId') ?? selectedFrameId;
    ownedAvatarIds
      ..clear()
      ..addAll(prefs.getStringList('ownedAvatarIds') ?? const ['smile']);
    ownedFrameIds
      ..clear()
      ..addAll(prefs.getStringList('ownedFrameIds') ?? const ['soft']);
    ownedMessageIds
      ..clear()
      ..addAll(prefs.getStringList('ownedMessageIds') ?? const ['good', 'move', 'win', 'again', 'thanks']);

    if (!ownedAvatarIds.contains(selectedAvatarId)) selectedAvatarId = 'smile';
    if (!ownedFrameIds.contains(selectedFrameId)) selectedFrameId = 'soft';
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('coins', coins);
    await prefs.setString('selectedAvatarId', selectedAvatarId);
    await prefs.setString('selectedFrameId', selectedFrameId);
    await prefs.setStringList('ownedAvatarIds', ownedAvatarIds.toList());
    await prefs.setStringList('ownedFrameIds', ownedFrameIds.toList());
    await prefs.setStringList('ownedMessageIds', ownedMessageIds.toList());
  }

  bool ownsAvatar(String id) => ownedAvatarIds.contains(id);
  bool ownsFrame(String id) => ownedFrameIds.contains(id);
  bool ownsMessage(String id) => ownedMessageIds.contains(id);

  Future<bool> buyOrSelectAvatar(AvatarItem item) async {
    if (ownsAvatar(item.id)) {
      selectedAvatarId = item.id;
      await _save();
      notifyListeners();
      return true;
    }
    if (coins < item.price) return false;
    coins -= item.price;
    ownedAvatarIds.add(item.id);
    selectedAvatarId = item.id;
    await _save();
    notifyListeners();
    return true;
  }

  Future<bool> buyOrSelectFrame(FrameItem item) async {
    if (ownsFrame(item.id)) {
      selectedFrameId = item.id;
      await _save();
      notifyListeners();
      return true;
    }
    if (coins < item.price) return false;
    coins -= item.price;
    ownedFrameIds.add(item.id);
    selectedFrameId = item.id;
    await _save();
    notifyListeners();
    return true;
  }

  Future<bool> buyMessage(MessageItem item) async {
    if (ownsMessage(item.id)) return true;
    if (coins < item.price) return false;
    coins -= item.price;
    ownedMessageIds.add(item.id);
    await _save();
    notifyListeners();
    return true;
  }
}

String toPersianDigits(Object input) {
  const map = {'0': '۰', '1': '۱', '2': '۲', '3': '۳', '4': '۴', '5': '۵', '6': '۶', '7': '۷', '8': '۸', '9': '۹'};
  return input.toString().split('').map((ch) => map[ch] ?? ch).join();
}
