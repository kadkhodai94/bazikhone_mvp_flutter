class PlayerModel {
  const PlayerModel({
    required this.name,
    required this.avatarAsset,
    required this.score,
    required this.level,
    this.isSystem = false,
  });

  final String name;
  final String avatarAsset;
  final int score;
  final String level;
  final bool isSystem;
}
