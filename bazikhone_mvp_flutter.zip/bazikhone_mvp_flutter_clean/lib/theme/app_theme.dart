import 'package:flutter/material.dart';

class AppColors {
  static const Color bg = Color(0xFFFFF7EC);
  static const Color surface = Color(0xFFFFFCF6);
  static const Color text = Color(0xFF211832);
  static const Color muted = Color(0xFF80778C);
  static const Color primary = Color(0xFFFF7548);
  static const Color purple = Color(0xFF7657E9);
  static const Color blue = Color(0xFF2791F4);
  static const Color pink = Color(0xFFFF4F86);
  static const Color yellow = Color(0xFFFFC53D);
  static const Color border = Color(0xFFEFE3D6);
}

class AppShadows {
  static const BoxShadow card = BoxShadow(
    color: Color(0x15000000),
    blurRadius: 22,
    offset: Offset(0, 10),
  );

  static const BoxShadow soft = BoxShadow(
    color: Color(0x0F000000),
    blurRadius: 16,
    offset: Offset(0, 6),
  );
}

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'sans',
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      background: AppColors.bg,
      surface: AppColors.surface,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      elevation: 0,
      centerTitle: true,
      iconTheme: IconThemeData(color: AppColors.text, size: 28),
      titleTextStyle: TextStyle(
        color: AppColors.text,
        fontSize: 24,
        fontWeight: FontWeight.w900,
        fontFamily: 'sans',
      ),
    ),
    textTheme: const TextTheme(
      headlineMedium: TextStyle(color: AppColors.text, fontSize: 32, fontWeight: FontWeight.w900),
      titleLarge: TextStyle(color: AppColors.text, fontSize: 24, fontWeight: FontWeight.w900),
      titleMedium: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900),
      bodyMedium: TextStyle(color: AppColors.muted, fontSize: 14, fontWeight: FontWeight.w700),
    ),
  );
}

class Assets {
  static const String homeHero = 'assets/images/home_hero.png';
  static const String avatarUser = 'assets/images/avatar_user.png';
  static const String iconXox = 'assets/images/icon_xox.png';
  static const String iconRps = 'assets/images/icon_rps.png';
  static const String iconConnect = 'assets/images/icon_connect.png';
  static const String iconWord = 'assets/images/icon_word.png';
  static const String iconLightning = 'assets/images/icon_lightning.png';
  static const String iconTrophy = 'assets/images/icon_trophy.png';
  static const String iconCrown = 'assets/images/icon_crown.png';
  static const String robot = 'assets/images/robot.png';
  static const String avatarOpponent = 'assets/images/avatar_opponent.png';
  static const String footerArcade = 'assets/images/footer_arcade.png';
}
