import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'state/player_inventory.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PlayerInventory.instance.load();
  runApp(const BazikhoneApp());
}

class BazikhoneApp extends StatelessWidget {
  const BazikhoneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بازی‌خونه',
      theme: buildTheme(),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HomeScreen(),
    );
  }
}
