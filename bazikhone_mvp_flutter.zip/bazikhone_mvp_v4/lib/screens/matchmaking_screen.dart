import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import 'xox_game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  static const int totalSeconds = 10;
  int secondsLeft = totalSeconds;
  bool opponentReady = false;
  Timer? timer;

  final opponents = const [
    PlayerModel(name: 'مهدی', avatarAsset: Assets.avatarOpponent, score: 1320, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'نیما', avatarAsset: Assets.avatarOpponent, score: 980, level: 'آسان', isSystem: true),
    PlayerModel(name: 'شاهین', avatarAsset: Assets.avatarOpponent, score: 1460, level: 'سخت', isSystem: true),
    PlayerModel(name: 'امیر', avatarAsset: Assets.avatarOpponent, score: 1240, level: 'متوسط', isSystem: true),
  ];

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (secondsLeft <= 1) {
        _startGameWithReadyOpponent();
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _startGameWithReadyOpponent() async {
    if (opponentReady) return;
    timer?.cancel();
    setState(() {
      secondsLeft = 0;
      opponentReady = true;
    });
    await Future<void>.delayed(const Duration(milliseconds: 750));
    if (!mounted) return;
    final opponent = opponents[Random().nextInt(opponents.length)];
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => XoxGameScreen(opponent: opponent)));
  }

  @override
  Widget build(BuildContext context) {
    final progress = secondsLeft / totalSeconds;

    return Scaffold(
      appBar: AppBar(title: const Text('یافتن حریف')),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Opacity(
                opacity: 0.74,
                child: Image.asset(Assets.footerArcade, height: 124, fit: BoxFit.cover),
              ),
            ),
            ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 160),
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(18, 34, 18, 28),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(34),
                    border: Border.all(color: AppColors.border),
                    boxShadow: const [AppShadows.card],
                  ),
                  child: Column(
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: opponentReady
                            ? const _ReadyMark(key: ValueKey('ready'))
                            : _TimerVisual(key: const ValueKey('timer'), progress: progress, seconds: secondsLeft),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        opponentReady ? 'حریف آماده شد' : 'در حال جستجوی حریف...',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: AppColors.text),
                      ),
                      const SizedBox(height: 9),
                      const Text(
                        'اگر حریف واقعی پیدا نشود، بازی معطل نمی‌ماند.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.muted, fontSize: 14, fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: const [
                    Expanded(child: Divider(color: AppColors.border, thickness: 1.2)),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: Text('یا بازی با', style: TextStyle(color: Color(0xFFB39169), fontSize: 18, fontWeight: FontWeight.w900)),
                    ),
                    Expanded(child: Divider(color: AppColors.border, thickness: 1.2)),
                  ],
                ),
                const SizedBox(height: 18),
                const _ReadyOpponentCard(),
                const SizedBox(height: 18),
                TextButton.icon(
                  onPressed: _startGameWithReadyOpponent,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('شروع فوری'),
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TimerVisual extends StatelessWidget {
  const _TimerVisual({super.key, required this.progress, required this.seconds});

  final double progress;
  final int seconds;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240,
      height: 240,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(size: const Size(230, 230), painter: _RingPainter(progress: progress)),
          Container(
            width: 148,
            height: 148,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [Color(0xFFFFF4EC), Color(0xFFEDEAFF)]),
              boxShadow: [BoxShadow(color: AppColors.purple.withOpacity(0.10), blurRadius: 25, offset: const Offset(0, 12))],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('$seconds', style: const TextStyle(color: AppColors.purple, fontSize: 58, height: 1, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('ثانیه', style: TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  const _RingPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final center = rect.center;
    final radius = size.width / 2 - 13;
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFFEFE2D4);
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -2.10, 4.20, false, base);

    final gradient = const SweepGradient(
      startAngle: -2.10,
      endAngle: 2.10,
      colors: [AppColors.primary, AppColors.pink, AppColors.purple, AppColors.primary],
    );
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round
      ..shader = gradient.createShader(rect);
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -2.10, 4.20 * progress, false, paint);
  }

  @override
  bool shouldRepaint(covariant _RingPainter oldDelegate) => oldDelegate.progress != progress;
}

class _ReadyMark extends StatelessWidget {
  const _ReadyMark({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 210,
      height: 210,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(colors: [Color(0xFFE7FFF4), Color(0xFFF0EAFF)]),
        boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.10), blurRadius: 28, offset: const Offset(0, 12))],
      ),
      child: const Icon(Icons.sports_esports_rounded, color: AppColors.purple, size: 92),
    );
  }
}

class _ReadyOpponentCard extends StatelessWidget {
  const _ReadyOpponentCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.border),
        boxShadow: const [AppShadows.soft],
      ),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          children: [
            SizedBox(width: 105, height: 92, child: Image.asset(Assets.robot, fit: BoxFit.contain)),
            Container(width: 1, height: 92, color: AppColors.border),
            const SizedBox(width: 18),
            Expanded(
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('حریف آماده', style: TextStyle(color: AppColors.text, fontSize: 22, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 10),
                    const Text('سطح پیشنهادی: متوسط', style: TextStyle(color: AppColors.muted, fontSize: 14, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(99),
                            child: LinearProgressIndicator(
                              minHeight: 8,
                              value: 0.72,
                              color: AppColors.purple,
                              backgroundColor: AppColors.border,
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        const Text('1240', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 18)),
                        const SizedBox(width: 5),
                        const Icon(Icons.star_rounded, color: AppColors.yellow, size: 25),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
