import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const _BottomNav(),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
          children: [
            const _TopBar(),
            const SizedBox(height: 16),
            const _HeroBanner(),
            const SizedBox(height: 22),
            Align(
              alignment: Alignment.centerRight,
              child: Text('بازی های نوستالژی', style: Theme.of(context).textTheme.titleLarge),
            ),
            const SizedBox(height: 14),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              childAspectRatio: 1.26,
              children: [
                _GameTile(
                  title: 'دوز / XOX',
                  image: Assets.iconXox,
                  onTap: () => _startQuickGame(context),
                ),
                const _GameTile(title: 'سنگ کاغذ قیچی', image: Assets.iconRps),
                const _GameTile(title: 'چهار در یک ردیف', image: Assets.iconConnect),
                const _GameTile(title: 'حدس کلمه', image: Assets.iconWord),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _ActionTile(
                    title: 'بازی سریع',
                    image: Assets.iconLightning,
                    color: const Color(0xFFFFF5DA),
                    onTap: () => _startQuickGame(context),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _ActionTile(
                    title: 'مسابقات',
                    image: Assets.iconTrophy,
                    color: const Color(0xFFF4EFFF),
                    onTap: () => _comingSoon(context, 'مسابقات'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _ActionTile(
                    title: 'اشتراک ویژه',
                    image: Assets.iconCrown,
                    color: const Color(0xFFFFEDF5),
                    onTap: () => _comingSoon(context, 'اشتراک ویژه'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _WideButton(
                    text: 'رتبه‌بندی',
                    icon: Icons.leaderboard_rounded,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _WideButton(
                    text: 'فروشگاه',
                    icon: Icons.storefront_rounded,
                    onTap: () => _comingSoon(context, 'فروشگاه آیتم‌ها'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MatchmakingScreen()));
  }

  void _comingSoon(BuildContext context, String title) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title در نسخه بعدی فعال می‌شود.')));
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 72,
                height: 72,
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.purple.withOpacity(0.75), width: 2),
                ),
                child: ClipOval(child: Image.asset(Assets.avatarUser, fit: BoxFit.cover)),
              ),
              Positioned(
                right: -8,
                bottom: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.purple,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: const [AppShadows.soft],
                  ),
                  child: const Text('23', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.border),
              boxShadow: const [AppShadows.soft],
            ),
            child: Row(
              children: const [
                Icon(Icons.stars_rounded, color: AppColors.yellow, size: 28),
                SizedBox(width: 12),
                Text('۲,۴۵۰', style: TextStyle(color: AppColors.text, fontSize: 19, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          const Spacer(),
          IconButton(
            iconSize: 34,
            color: const Color(0xFF60606A),
            onPressed: () {},
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
    );
  }
}

class _HeroBanner extends StatelessWidget {
  const _HeroBanner();

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 796 / 473,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Image.asset(Assets.homeHero, fit: BoxFit.cover),
      ),
    );
  }
}

class _GameTile extends StatelessWidget {
  const _GameTile({required this.title, required this.image, this.onTap});

  final String title;
  final String image;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(28),
      elevation: 0,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(28),
        child: Container(
          padding: const EdgeInsets.fromLTRB(10, 16, 10, 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.border),
            boxShadow: const [AppShadows.soft],
            color: AppColors.surface,
          ),
          child: Column(
            children: [
              Expanded(child: Image.asset(image, fit: BoxFit.contain)),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.text, fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.title, required this.image, required this.color, this.onTap});

  final String title;
  final String image;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 128,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.9)),
          boxShadow: const [AppShadows.soft],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(child: Image.asset(image, fit: BoxFit.contain)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w900, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class _WideButton extends StatelessWidget {
  const _WideButton({required this.text, required this.icon, required this.onTap});

  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.soft],
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.text, size: 24),
            const SizedBox(width: 8),
            Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: AppColors.text)),
          ],
        ),
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  const _BottomNav();

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.home_rounded, 'خانه', true),
      (Icons.grid_view_rounded, 'دسته‌بندی', false),
      (Icons.group_rounded, 'دوستان', false),
      (Icons.storefront_rounded, 'فروشگاه', false),
      (Icons.person_outline_rounded, 'پروفایل', false),
    ];

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 10),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.border),
          boxShadow: const [AppShadows.card],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (final item in items)
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.$1, color: item.$3 ? AppColors.purple : Colors.grey.shade600, size: 25),
                  const SizedBox(height: 3),
                  Text(
                    item.$2,
                    style: TextStyle(
                      color: item.$3 ? AppColors.purple : Colors.grey.shade600,
                      fontWeight: FontWeight.w900,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
