import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  static const players = [
    ('آرمان', '😎', 2560),
    ('سارا', '🙂', 2180),
    ('مهدی', '🤓', 1930),
    ('نیما', '🧢', 1640),
    ('شما', '🙂', 1240),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رتبه‌بندی')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFE4D2), Color(0xFFEDE8FF)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.10),
                    blurRadius: 24,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: const Row(
                children: [
                  Text('🏆', style: TextStyle(fontSize: 52)),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'برترین‌های بازی‌خونه',
                          style: TextStyle(
                            color: AppColors.text,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'رتبه‌بندی نمونه برای نسخه دوم MVP',
                          style: TextStyle(
                            color: AppColors.mutedText,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const _Tabs(),
            const SizedBox(height: 16),
            ...List.generate(players.length, (index) {
              final player = players[index];
              return _LeaderboardTile(
                rank: index + 1,
                name: player.$1,
                avatar: player.$2,
                score: player.$3,
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _Tabs extends StatelessWidget {
  const _Tabs();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: const [
          _TabItem(text: 'امروز', active: true),
          _TabItem(text: 'هفته'),
          _TabItem(text: 'ماه'),
        ],
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  const _TabItem({required this.text, this.active = false});

  final String text;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          color: active ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: TextStyle(
            color: active ? Colors.white : AppColors.mutedText,
            fontWeight: FontWeight.w900,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}

class _LeaderboardTile extends StatelessWidget {
  const _LeaderboardTile({
    required this.rank,
    required this.name,
    required this.avatar,
    required this.score,
  });

  final int rank;
  final String name;
  final String avatar;
  final int score;

  @override
  Widget build(BuildContext context) {
    final isTopThree = rank <= 3;
    final rankColor = rank == 1
        ? AppColors.yellow
        : rank == 2
            ? AppColors.purple
            : rank == 3
                ? AppColors.primary
                : AppColors.border;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: name == 'شما' ? AppColors.primary.withOpacity(0.07) : AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: name == 'شما' ? AppColors.primary.withOpacity(0.25) : AppColors.border),
        boxShadow: [
          if (isTopThree)
            BoxShadow(
              color: rankColor.withOpacity(0.14),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: rankColor.withOpacity(0.18),
              borderRadius: BorderRadius.circular(15),
            ),
            alignment: Alignment.center,
            child: Text(
              '$rank',
              style: const TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text(avatar, style: const TextStyle(fontSize: 26)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: AppColors.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (name == 'شما')
                  const Text(
                    'جایگاه فعلی شما',
                    style: TextStyle(
                      color: AppColors.primary,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
              ],
            ),
          ),
          const Icon(Icons.star_rounded, color: AppColors.yellow),
          const SizedBox(width: 4),
          Text(
            '$score',
            style: const TextStyle(
              color: AppColors.text,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
