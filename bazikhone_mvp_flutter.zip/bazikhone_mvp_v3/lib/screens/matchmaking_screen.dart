import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import 'xox_game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  static const int totalSeconds = 10;
  int secondsLeft = totalSeconds;
  bool opponentReady = false;
  Timer? timer;

  final opponents = const [
    PlayerModel(name: 'امیر', avatarEmoji: '😎', score: 1240, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'سارا', avatarEmoji: '🙂', score: 1180, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'نیما', avatarEmoji: '🧢', score: 980, level: 'آسان', isSystem: true),
    PlayerModel(name: 'شاهین', avatarEmoji: '🎮', score: 1460, level: 'سخت', isSystem: true),
    PlayerModel(name: 'مهدی', avatarEmoji: '🧔', score: 1320, level: 'متوسط', isSystem: true),
  ];

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (secondsLeft <= 1) {
        _showReadyThenStart();
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _showReadyThenStart() async {
    if (opponentReady) return;
    timer?.cancel();
    if (!mounted) return;
    setState(() {
      secondsLeft = 0;
      opponentReady = true;
    });
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted) return;
    final opponent = opponents[Random().nextInt(opponents.length)];
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => XoxGameScreen(opponent: opponent)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = secondsLeft / totalSeconds;

    return Scaffold(
      appBar: AppBar(title: const Text('یافتن حریف')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: AppColors.border),
                boxShadow: const [AppShadows.soft],
              ),
              child: Column(
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 280),
                    child: opponentReady
                        ? const _ReadyBadge(key: ValueKey('ready'))
                        : _TimerCircle(
                            key: const ValueKey('timer'),
                            progress: progress,
                            secondsLeft: secondsLeft,
                          ),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    opponentReady ? 'حریف آماده شد 🎮' : 'در حال جستجوی حریف...',
                    style: const TextStyle(
                      color: AppColors.text,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 7),
                  const Text(
                    'اگر حریف واقعی پیدا نشود، بازی معطل نمی‌ماند.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.mutedText,
                      fontWeight: FontWeight.w700,
                      fontSize: 12.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const _OpponentPreview(),
            const SizedBox(height: 14),
            const _TipCard(),
            const SizedBox(height: 18),
            TextButton.icon(
              onPressed: _showReadyThenStart,
              icon: const Icon(Icons.double_arrow_rounded, size: 18),
              label: const Text('نمی‌خوای منتظر بمونی؟ شروع کن'),
              style: TextButton.styleFrom(
                foregroundColor: AppColors.primary,
                textStyle: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TimerCircle extends StatelessWidget {
  const _TimerCircle({super.key, required this.progress, required this.secondsLeft});

  final double progress;
  final int secondsLeft;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 168,
      height: 168,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 160,
            height: 160,
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: 12,
              strokeCap: StrokeCap.round,
              backgroundColor: AppColors.border,
              color: AppColors.primary,
            ),
          ),
          Container(
            width: 116,
            height: 116,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFFF4EC), Color(0xFFEDEAFF)],
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.10),
                  blurRadius: 22,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '$secondsLeft',
                  style: const TextStyle(
                    color: AppColors.purple,
                    fontSize: 42,
                    fontWeight: FontWeight.w900,
                    height: 1,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'ثانیه',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReadyBadge extends StatelessWidget {
  const _ReadyBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 168,
      height: 168,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFFFFE8D8), Color(0xFFEAE5FF)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.green.withOpacity(0.14),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: const Icon(Icons.check_circle_rounded, color: AppColors.green, size: 74),
    );
  }
}

class _OpponentPreview extends StatelessWidget {
  const _OpponentPreview();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: const [AppShadows.tiny],
      ),
      child: Row(
        children: [
          Container(
            width: 66,
            height: 66,
            decoration: BoxDecoration(
              color: AppColors.blue.withOpacity(0.09),
              borderRadius: BorderRadius.circular(23),
            ),
            alignment: Alignment.center,
            child: const Text('🎮', style: TextStyle(fontSize: 31)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'حریف آماده',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                  ),
                ),
                const SizedBox(height: 7),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: const LinearProgressIndicator(
                    value: 0.58,
                    minHeight: 7,
                    backgroundColor: AppColors.border,
                    color: AppColors.purple,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'سطح پیشنهادی: متوسط',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Icon(Icons.star_rounded, color: AppColors.yellow),
          const Text(
            '1240',
            style: TextStyle(
              color: AppColors.text,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _TipCard extends StatelessWidget {
  const _TipCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFEEE3), Color(0xFFECE7FF)],
        ),
      ),
      child: const Row(
        children: [
          Icon(Icons.lightbulb_rounded, color: AppColors.primary),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'هر دست سریع‌تر تمام شود، امتیاز بیشتری می‌گیری.',
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
