import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/game_card.dart';
import '../widgets/primary_button.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 20),
          children: [
            const _TopBar(),
            const SizedBox(height: 14),
            const _HeroCard(),
            const SizedBox(height: 20),
            Row(
              children: [
                Text('بازی‌های نوستالژی', style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                const Text(
                  'نسخه آزمایشی',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.12,
              children: [
                GameCard(
                  title: 'دوز / XOX',
                  subtitle: 'شروع سریع',
                  icon: 'XO',
                  color: AppColors.blue,
                  isAvailable: true,
                  onTap: () => _startQuickGame(context),
                ),
                const GameCard(
                  title: 'سنگ کاغذ قیچی',
                  subtitle: 'به‌زودی',
                  icon: '✊',
                  color: AppColors.yellow,
                ),
                const GameCard(
                  title: 'چهار در یک ردیف',
                  subtitle: 'به‌زودی',
                  icon: '●●',
                  color: AppColors.purple,
                ),
                const GameCard(
                  title: 'حدس کلمه',
                  subtitle: 'به‌زودی',
                  icon: '?',
                  color: AppColors.pink,
                ),
              ],
            ),
            const SizedBox(height: 18),
            PrimaryButton(
              text: 'بازی سریع',
              icon: Icons.flash_on_rounded,
              onPressed: () => _startQuickGame(context),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: PrimaryButton(
                    text: 'رتبه‌بندی',
                    icon: Icons.leaderboard_rounded,
                    isSecondary: true,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PrimaryButton(
                    text: 'اشتراک ویژه',
                    icon: Icons.workspace_premium_rounded,
                    isSecondary: true,
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('اشتراک ویژه در نسخه بعدی فعال می‌شود.')),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            const _TodayMissionCard(),
          ],
        ),
      ),
    );
  }

  void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MatchmakingScreen()),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: AppColors.border),
            boxShadow: const [AppShadows.soft],
          ),
          alignment: Alignment.center,
          child: const Text('🙂', style: TextStyle(fontSize: 23)),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'سلام، خوش اومدی',
                style: TextStyle(
                  color: AppColors.mutedText,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
              SizedBox(height: 2),
              Text(
                'آماده رقابتی؟',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
            boxShadow: const [AppShadows.tiny],
          ),
          child: const Row(
            children: [
              Icon(Icons.monetization_on_rounded, color: AppColors.yellow, size: 20),
              SizedBox(width: 6),
              Text(
                '۲۴۵۰',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: AppColors.text,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 184,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color(0xFFFFE8D6),
            Color(0xFFF1EAFF),
            Color(0xFFE2F4FF),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.12),
            blurRadius: 26,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 82,
            height: 82,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.48),
              borderRadius: BorderRadius.circular(28),
            ),
            alignment: Alignment.center,
            child: const Text('🕹️', style: TextStyle(fontSize: 48)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.76),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      'نسخه سوم MVP',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: AppColors.purple,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text('بازی‌خونه', style: Theme.of(context).textTheme.headlineLarge),
                const SizedBox(height: 4),
                const Text(
                  'بازی‌های خاطره‌انگیز، رقابت مدرن',
                  style: TextStyle(
                    fontSize: 13,
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const Spacer(),
                const Row(
                  children: [
                    _MiniInfo(icon: Icons.flash_on_rounded, text: 'سریع'),
                    SizedBox(width: 7),
                    _MiniInfo(icon: Icons.emoji_events_rounded, text: 'رقابتی'),
                    SizedBox(width: 7),
                    _MiniInfo(icon: Icons.auto_awesome_rounded, text: 'نوستالژی'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniInfo extends StatelessWidget {
  const _MiniInfo({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.78),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppColors.primary, size: 15),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayMissionCard extends StatelessWidget {
  const _TodayMissionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border),
        boxShadow: const [AppShadows.tiny],
      ),
      child: const Row(
        children: [
          Icon(Icons.local_fire_department_rounded, color: AppColors.primary, size: 28),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ماموریت امروز',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '۳ دست دوز بازی کن و ۵۰ سکه بگیر',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_left_rounded, color: AppColors.mutedText),
        ],
      ),
    );
  }
}
