class PlayerModel {
  const PlayerModel({
    required this.name,
    required this.avatarEmoji,
    required this.score,
    required this.level,
    this.isSystem = false,
  });

  final String name;
  final String avatarEmoji;
  final int score;
  final String level;
  final bool isSystem;
}
