import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFFFFF8EF);
  static const background2 = Color(0xFFFFF1E5);
  static const surface = Color(0xFFFFFFFF);
  static const softSurface = Color(0xFFFFFBF6);
  static const primary = Color(0xFFFF7442);
  static const primaryDark = Color(0xFFE85C2D);
  static const purple = Color(0xFF795DFF);
  static const blue = Color(0xFF348CFF);
  static const pink = Color(0xFFFF547F);
  static const yellow = Color(0xFFFFC857);
  static const text = Color(0xFF25182F);
  static const mutedText = Color(0xFF7F7489);
  static const border = Color(0xFFF1E2D5);
  static const green = Color(0xFF25B67B);
  static const danger = Color(0xFFFF5C7A);
}

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.background,
      fontFamily: null,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: Brightness.light,
      ).copyWith(
        primary: AppColors.primary,
        secondary: AppColors.purple,
        surface: AppColors.surface,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 31,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
          height: 1.25,
        ),
        headlineMedium: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
          height: 1.3,
        ),
        titleLarge: TextStyle(
          fontSize: 21,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
        ),
        titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
        ),
        bodyLarge: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: AppColors.text,
          height: 1.7,
        ),
        bodyMedium: TextStyle(
          fontSize: 13,
          color: AppColors.mutedText,
          height: 1.6,
          fontWeight: FontWeight.w600,
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.text,
        centerTitle: true,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: AppColors.text,
          fontSize: 20,
          fontWeight: FontWeight.w900,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.text,
        contentTextStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
