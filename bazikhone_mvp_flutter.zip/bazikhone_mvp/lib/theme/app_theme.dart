import 'package:flutter/material.dart';

class AppColors {
  static const background = Color(0xFFFFF8EF);
  static const surface = Color(0xFFFFFFFF);
  static const primary = Color(0xFFFF7A45);
  static const primaryDark = Color(0xFFEA5F2E);
  static const purple = Color(0xFF7C5CFF);
  static const blue = Color(0xFF3A8DFF);
  static const pink = Color(0xFFFF5FA2);
  static const yellow = Color(0xFFFFC857);
  static const text = Color(0xFF271B32);
  static const mutedText = Color(0xFF7C7189);
  static const border = Color(0xFFF0E3D6);
  static const green = Color(0xFF25B67B);
  static const danger = Color(0xFFFF5C7A);
}

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        brightness: Brightness.light,
      ).copyWith(
        primary: AppColors.primary,
        secondary: AppColors.purple,
        surface: AppColors.surface,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 30,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
          height: 1.25,
        ),
        headlineMedium: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w900,
          color: AppColors.text,
          height: 1.25,
        ),
        titleLarge: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w800,
          color: AppColors.text,
        ),
        titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w800,
          color: AppColors.text,
        ),
        bodyLarge: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: AppColors.text,
          height: 1.7,
        ),
        bodyMedium: TextStyle(
          fontSize: 13,
          color: AppColors.mutedText,
          height: 1.6,
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.text,
        centerTitle: true,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: AppColors.text,
          fontSize: 18,
          fontWeight: FontWeight.w900,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.text,
        contentTextStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
