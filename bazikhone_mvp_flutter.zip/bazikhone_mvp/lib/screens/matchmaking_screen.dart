import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import '../widgets/primary_button.dart';
import 'xox_game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  static const int totalSeconds = 10;
  int secondsLeft = totalSeconds;
  bool opponentReady = false;
  Timer? timer;

  final opponents = const [
    PlayerModel(name: 'امیر', avatarEmoji: '😎', score: 1240, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'سارا', avatarEmoji: '🙂', score: 1180, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'نیما', avatarEmoji: '🤓', score: 980, level: 'آسان', isSystem: true),
    PlayerModel(name: 'شاهین', avatarEmoji: '🧢', score: 1460, level: 'سخت', isSystem: true),
    PlayerModel(name: 'مهدی', avatarEmoji: '🧔', score: 1320, level: 'متوسط', isSystem: true),
  ];

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (secondsLeft <= 1) {
        _showReadyThenStart();
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _showReadyThenStart() async {
    timer?.cancel();
    if (!mounted) return;
    setState(() {
      secondsLeft = 0;
      opponentReady = true;
    });
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted) return;
    final opponent = opponents[Random().nextInt(opponents.length)];
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => XoxGameScreen(opponent: opponent)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = secondsLeft / totalSeconds;

    return Scaffold(
      appBar: AppBar(
        title: const Text('یافتن حریف'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(34),
                        border: Border.all(color: AppColors.border),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.purple.withOpacity(0.08),
                            blurRadius: 30,
                            offset: const Offset(0, 16),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 300),
                            child: opponentReady
                                ? const _ReadyBadge()
                                : _TimerCircle(progress: progress, secondsLeft: secondsLeft),
                          ),
                          const SizedBox(height: 22),
                          Text(
                            opponentReady ? 'حریف آماده شد 🎮' : 'در حال جستجوی حریف...',
                            style: const TextStyle(
                              color: AppColors.text,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'حداکثر زمان انتظار ۱۰ ثانیه است.',
                            style: TextStyle(
                              color: AppColors.mutedText,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: const [
                        Expanded(child: Divider(color: AppColors.border)),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Text(
                            'در صورت نبود حریف',
                            style: TextStyle(
                              color: AppColors.mutedText,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        Expanded(child: Divider(color: AppColors.border)),
                      ],
                    ),
                    const SizedBox(height: 18),
                    const _ReadyOpponentPreview(),
                    const SizedBox(height: 18),
                    const _TipCard(),
                  ],
                ),
              ),
              PrimaryButton(
                text: 'شروع فوری',
                icon: Icons.play_arrow_rounded,
                onPressed: _showReadyThenStart,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TimerCircle extends StatelessWidget {
  const _TimerCircle({required this.progress, required this.secondsLeft});

  final double progress;
  final int secondsLeft;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 180,
      height: 180,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 174,
            height: 174,
            child: CircularProgressIndicator(
              value: progress,
              strokeWidth: 13,
              strokeCap: StrokeCap.round,
              backgroundColor: AppColors.border,
              color: AppColors.primary,
            ),
          ),
          Container(
            width: 126,
            height: 126,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFFFF4EC), Color(0xFFEDEAFF)],
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.12),
                  blurRadius: 25,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '$secondsLeft',
                  style: const TextStyle(
                    color: AppColors.purple,
                    fontSize: 44,
                    fontWeight: FontWeight.w900,
                    height: 1,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'ثانیه',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReadyBadge extends StatelessWidget {
  const _ReadyBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      height: 180,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFFFFE8D8), Color(0xFFEAE5FF)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.green.withOpacity(0.16),
            blurRadius: 30,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: const Icon(Icons.check_circle_rounded, color: AppColors.green, size: 78),
    );
  }
}

class _ReadyOpponentPreview extends StatelessWidget {
  const _ReadyOpponentPreview();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 74,
            height: 74,
            decoration: BoxDecoration(
              color: AppColors.blue.withOpacity(0.09),
              borderRadius: BorderRadius.circular(26),
            ),
            alignment: Alignment.center,
            child: const Text('🎮', style: TextStyle(fontSize: 34)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'حریف آماده',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                  ),
                ),
                const SizedBox(height: 7),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: const LinearProgressIndicator(
                    value: 0.58,
                    minHeight: 7,
                    backgroundColor: AppColors.border,
                    color: AppColors.purple,
                  ),
                ),
                const SizedBox(height: 7),
                const Text(
                  'سطح پیشنهادی: متوسط',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          const Icon(Icons.star_rounded, color: AppColors.yellow),
          const Text(
            '1240',
            style: TextStyle(
              color: AppColors.text,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _TipCard extends StatelessWidget {
  const _TipCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFEEE3), Color(0xFFECE7FF)],
        ),
      ),
      child: const Row(
        children: [
          Icon(Icons.lightbulb_rounded, color: AppColors.primary),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'بردهای سریع امتیاز بیشتری می‌گیرند.',
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
