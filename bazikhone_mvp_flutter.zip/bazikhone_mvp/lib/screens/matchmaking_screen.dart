import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import '../widgets/primary_button.dart';
import 'xox_game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  const MatchmakingScreen({super.key});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen> {
  static const int totalSeconds = 10;
  int secondsLeft = totalSeconds;
  Timer? timer;

  final opponents = const [
    PlayerModel(name: 'امیر', avatarEmoji: '😎', score: 1240, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'سارا', avatarEmoji: '🙂', score: 1180, level: 'متوسط', isSystem: true),
    PlayerModel(name: 'نیما', avatarEmoji: '🤓', score: 980, level: 'آسان', isSystem: true),
    PlayerModel(name: 'شاهین', avatarEmoji: '🧢', score: 1460, level: 'سخت', isSystem: true),
  ];

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (secondsLeft <= 1) {
        _startReadyOpponentGame();
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _startReadyOpponentGame() {
    timer?.cancel();
    final opponent = opponents[Random().nextInt(opponents.length)];

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => XoxGameScreen(opponent: opponent),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = secondsLeft / totalSeconds;

    return Scaffold(
      appBar: AppBar(
        title: const Text('یافتن حریف'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: AppColors.border),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.purple.withOpacity(0.10),
                          blurRadius: 30,
                          offset: const Offset(0, 16),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              width: 180,
                              height: 180,
                              child: CircularProgressIndicator(
                                value: progress,
                                strokeWidth: 14,
                                strokeCap: StrokeCap.round,
                                backgroundColor: AppColors.border,
                                color: AppColors.primary,
                              ),
                            ),
                            Column(
                              children: [
                                Text(
                                  '$secondsLeft',
                                  style: const TextStyle(
                                    fontSize: 46,
                                    fontWeight: FontWeight.w900,
                                    color: AppColors.text,
                                  ),
                                ),
                                const Text(
                                  'ثانیه',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.mutedText,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        Text(
                          'در حال یافتن حریف...',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'اگر حریف واقعی پیدا نشود، بازی بدون معطلی شروع می‌شود.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: AppColors.mutedText,
                            height: 1.7,
                          ),
                        ),
                        const SizedBox(height: 22),
                        const _ReadyOpponentPreview(),
                      ],
                    ),
                  ),
                ),
              ),
              PrimaryButton(
                text: 'شروع سریع با حریف آماده',
                icon: Icons.sports_esports_rounded,
                onPressed: _startReadyOpponentGame,
              ),
              const SizedBox(height: 10),
              PrimaryButton(
                text: 'انصراف',
                icon: Icons.close_rounded,
                isSecondary: true,
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReadyOpponentPreview extends StatelessWidget {
  const _ReadyOpponentPreview();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5EA),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFFFE0C7)),
      ),
      child: const Row(
        children: [
          CircleAvatar(
            backgroundColor: Colors.white,
            radius: 24,
            child: Text('🎮', style: TextStyle(fontSize: 24)),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'حریف آماده',
                  style: TextStyle(
                    color: AppColors.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'سطح: متوسط  •  امتیاز: ۱۲۴۰',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
