import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import '../widgets/player_card.dart';
import '../widgets/primary_button.dart';

class XoxGameScreen extends StatefulWidget {
  const XoxGameScreen({super.key, required this.opponent});

  final PlayerModel opponent;

  @override
  State<XoxGameScreen> createState() => _XoxGameScreenState();
}

class _XoxGameScreenState extends State<XoxGameScreen> {
  final PlayerModel me = const PlayerModel(
    name: 'شما',
    avatarEmoji: '🙂',
    score: 2450,
    level: 'بازیکن',
  );

  List<String> board = List.filled(9, '');
  String currentTurn = 'X';
  String resultMessage = '';
  bool isOpponentThinking = false;
  int myWins = 0;
  int opponentWins = 0;
  int draws = 0;

  bool get isGameOver => resultMessage.isNotEmpty;

  void _onCellTap(int index) {
    if (board[index].isNotEmpty || currentTurn != 'X' || isGameOver || isOpponentThinking) {
      return;
    }

    setState(() {
      board[index] = 'X';
    });

    _evaluateAfterMove('X');

    if (!isGameOver) {
      setState(() {
        currentTurn = 'O';
        isOpponentThinking = true;
      });

      Future.delayed(const Duration(milliseconds: 650), () {
        if (!mounted || isGameOver) return;
        _makeOpponentMove();
      });
    }
  }

  void _makeOpponentMove() {
    final move = _chooseOpponentMove();

    setState(() {
      board[move] = 'O';
      isOpponentThinking = false;
    });

    _evaluateAfterMove('O');

    if (!isGameOver) {
      setState(() => currentTurn = 'X');
    }
  }

  int _chooseOpponentMove() {
    // اول اگر حریف می‌تواند ببرد، همان حرکت را می‌زند.
    final winningMove = _findBestImmediateMove('O');
    if (winningMove != null) return winningMove;

    // بعد جلوی برد فوری کاربر را می‌گیرد.
    final blockingMove = _findBestImmediateMove('X');
    if (blockingMove != null) return blockingMove;

    // مرکز ارزشمندترین خانه است.
    if (board[4].isEmpty) return 4;

    // گوشه‌ها حرکت‌های قوی‌تری هستند.
    final corners = [0, 2, 6, 8].where((i) => board[i].isEmpty).toList();
    if (corners.isNotEmpty) return corners[Random().nextInt(corners.length)];

    // در نهایت هر خانه خالی.
    final emptyCells = _emptyCells();
    return emptyCells[Random().nextInt(emptyCells.length)];
  }

  int? _findBestImmediateMove(String symbol) {
    for (final index in _emptyCells()) {
      final testBoard = [...board];
      testBoard[index] = symbol;
      if (_winnerFor(testBoard) == symbol) {
        return index;
      }
    }
    return null;
  }

  List<int> _emptyCells() {
    final cells = <int>[];
    for (var i = 0; i < board.length; i++) {
      if (board[i].isEmpty) cells.add(i);
    }
    return cells;
  }

  void _evaluateAfterMove(String symbol) {
    final winner = _winnerFor(board);
    if (winner == 'X') {
      setState(() {
        resultMessage = 'بردی! +۴ امتیاز';
        myWins++;
      });
      return;
    }

    if (winner == 'O') {
      setState(() {
        resultMessage = '${widget.opponent.name} برنده شد';
        opponentWins++;
      });
      return;
    }

    if (!board.contains('')) {
      setState(() {
        resultMessage = 'مساوی شد! +۱ امتیاز';
        draws++;
      });
    }
  }

  String? _winnerFor(List<String> cells) {
    const winLines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (final line in winLines) {
      final a = line[0];
      final b = line[1];
      final c = line[2];
      if (cells[a].isNotEmpty && cells[a] == cells[b] && cells[a] == cells[c]) {
        return cells[a];
      }
    }
    return null;
  }

  void _restartGame() {
    setState(() {
      board = List.filled(9, '');
      currentTurn = 'X';
      resultMessage = '';
      isOpponentThinking = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final turnText = isOpponentThinking
        ? '${widget.opponent.name} در حال فکر کردنه...'
        : isGameOver
            ? resultMessage
            : currentTurn == 'X'
                ? 'نوبت شما'
                : 'نوبت ${widget.opponent.name}';

    return Scaffold(
      appBar: AppBar(
        title: const Text('دوز / XOX'),
        actions: [
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('امکانات بیشتر در نسخه بعدی اضافه می‌شود.')),
              );
            },
            icon: const Icon(Icons.more_horiz_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            Row(
              children: [
                PlayerCard(
                  player: me.copyWithScore(myWins),
                  symbol: 'X',
                  color: AppColors.blue,
                  isActive: currentTurn == 'X' && !isGameOver,
                ),
                const SizedBox(width: 10),
                PlayerCard(
                  player: widget.opponent.copyWithScore(opponentWins),
                  symbol: 'O',
                  color: AppColors.danger,
                  isActive: currentTurn == 'O' && !isGameOver,
                ),
              ],
            ),
            const SizedBox(height: 16),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isGameOver ? AppColors.green.withOpacity(0.10) : AppColors.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: isGameOver ? AppColors.green.withOpacity(0.28) : AppColors.border,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    isGameOver ? Icons.emoji_events_rounded : Icons.touch_app_rounded,
                    color: isGameOver ? AppColors.green : AppColors.primary,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      turnText,
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AppColors.text,
                      ),
                    ),
                  ),
                  Text(
                    'مساوی: $draws',
                    style: const TextStyle(
                      color: AppColors.mutedText,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _Board(
              cells: board,
              onTap: _onCellTap,
            ),
            const SizedBox(height: 22),
            if (isGameOver)
              PrimaryButton(
                text: 'بازی دوباره',
                icon: Icons.refresh_rounded,
                onPressed: _restartGame,
              )
            else
              Row(
                children: [
                  SizedBox(
                    width: 58,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('چت در نسخه بعدی اضافه می‌شود.')),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.surface,
                        foregroundColor: AppColors.text,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                          side: const BorderSide(color: AppColors.border),
                        ),
                      ),
                      child: const Icon(Icons.chat_bubble_outline_rounded),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: PrimaryButton(
                      text: 'تسلیم شدن',
                      icon: Icons.flag_rounded,
                      isSecondary: true,
                      onPressed: () {
                        setState(() {
                          resultMessage = 'تسلیم شدی';
                          opponentWins++;
                        });
                      },
                    ),
                  ),
                ],
              ),
            const SizedBox(height: 18),
            const _NostalgiaFooter(),
          ],
        ),
      ),
    );
  }
}

extension PlayerScore on PlayerModel {
  PlayerModel copyWithScore(int newScore) {
    return PlayerModel(
      name: name,
      avatarEmoji: avatarEmoji,
      score: newScore,
      level: level,
      isSystem: isSystem,
    );
  }
}

class _Board extends StatelessWidget {
  const _Board({required this.cells, required this.onTap});

  final List<String> cells;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.purple.withOpacity(0.08),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: AspectRatio(
        aspectRatio: 1,
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 9,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (context, index) {
            final value = cells[index];
            return GestureDetector(
              onTap: () => onTap(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFBF7),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: value.isEmpty ? AppColors.border : AppColors.primary.withOpacity(0.28),
                  ),
                ),
                alignment: Alignment.center,
                child: AnimatedScale(
                  scale: value.isEmpty ? 0.7 : 1,
                  duration: const Duration(milliseconds: 200),
                  child: Text(
                    value,
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.w900,
                      color: value == 'X' ? AppColors.blue : AppColors.danger,
                      shadows: [
                        if (value.isNotEmpty)
                          Shadow(
                            color: (value == 'X' ? AppColors.blue : AppColors.danger).withOpacity(0.22),
                            blurRadius: 16,
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _NostalgiaFooter extends StatelessWidget {
  const _NostalgiaFooter();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFE5D4), Color(0xFFE9E2FF)],
        ),
      ),
      child: const Row(
        children: [
          Text('🌅', style: TextStyle(fontSize: 36)),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'حس بازی‌های قدیمی، با ظاهر مدرن و تمیز',
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
                height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
