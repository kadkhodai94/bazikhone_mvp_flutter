import 'dart:math';

import 'package:flutter/material.dart';

import '../models/player_model.dart';
import '../theme/app_theme.dart';
import '../widgets/player_card.dart';
import '../widgets/primary_button.dart';

class XoxGameScreen extends StatefulWidget {
  const XoxGameScreen({super.key, required this.opponent});

  final PlayerModel opponent;

  @override
  State<XoxGameScreen> createState() => _XoxGameScreenState();
}

class _XoxGameScreenState extends State<XoxGameScreen> {
  final PlayerModel me = const PlayerModel(
    name: 'شما',
    avatarEmoji: '🙂',
    score: 2450,
    level: 'بازیکن',
  );

  List<String> board = List.filled(9, '');
  String currentTurn = 'X';
  bool isOpponentThinking = false;
  String resultTitle = '';
  String resultSubtitle = '';
  int myWins = 0;
  int opponentWins = 0;
  int draws = 0;

  bool get isGameOver => resultTitle.isNotEmpty;

  void _onCellTap(int index) {
    if (board[index].isNotEmpty || currentTurn != 'X' || isGameOver || isOpponentThinking) {
      return;
    }

    setState(() => board[index] = 'X');
    if (_finishIfNeeded()) return;

    setState(() {
      currentTurn = 'O';
      isOpponentThinking = true;
    });

    Future.delayed(const Duration(milliseconds: 620), () {
      if (!mounted || isGameOver) return;
      _botMove();
    });
  }

  void _botMove() {
    final move = _bestBotMove();
    if (move == null) return;

    setState(() {
      board[move] = 'O';
      isOpponentThinking = false;
    });

    if (_finishIfNeeded()) return;
    setState(() => currentTurn = 'X');
  }

  int? _bestBotMove() {
    final empty = <int>[];
    for (var i = 0; i < board.length; i++) {
      if (board[i].isEmpty) empty.add(i);
    }
    if (empty.isEmpty) return null;

    final winMove = _findImmediateMove('O');
    if (winMove != null) return winMove;

    final blockMove = _findImmediateMove('X');
    if (blockMove != null) return blockMove;

    if (board[4].isEmpty) return 4;

    final corners = [0, 2, 6, 8].where((i) => board[i].isEmpty).toList();
    if (corners.isNotEmpty) return corners[Random().nextInt(corners.length)];

    return empty[Random().nextInt(empty.length)];
  }

  int? _findImmediateMove(String symbol) {
    for (var i = 0; i < board.length; i++) {
      if (board[i].isNotEmpty) continue;
      final copy = [...board];
      copy[i] = symbol;
      if (_winnerOf(copy) == symbol) return i;
    }
    return null;
  }

  bool _finishIfNeeded() {
    final result = _winnerOf(board);
    if (result == null) return false;

    setState(() {
      currentTurn = '';
      isOpponentThinking = false;
      if (result == 'X') {
        myWins++;
        resultTitle = 'بردی! +۳ امتیاز';
        resultSubtitle = 'حریف رو با یک حرکت تمیز بردی.';
      } else if (result == 'O') {
        opponentWins++;
        resultTitle = 'این دست رو باختی';
        resultSubtitle = 'دوباره بازی کن، شانس بعدی مال توئه.';
      } else {
        draws++;
        resultTitle = 'مساوی شد';
        resultSubtitle = 'بازی نزدیک بود؛ یک دست دیگه؟';
      }
    });

    return true;
  }

  String? _winnerOf(List<String> cells) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (final line in lines) {
      final a = cells[line[0]];
      if (a.isNotEmpty && a == cells[line[1]] && a == cells[line[2]]) {
        return a;
      }
    }

    if (cells.every((cell) => cell.isNotEmpty)) return 'draw';
    return null;
  }

  void _resetGame() {
    setState(() {
      board = List.filled(9, '');
      currentTurn = 'X';
      isOpponentThinking = false;
      resultTitle = '';
      resultSubtitle = '';
    });
  }

  void _surrender() {
    if (isGameOver) return;
    setState(() {
      opponentWins++;
      currentTurn = '';
      isOpponentThinking = false;
      resultTitle = 'تسلیم شدی';
      resultSubtitle = 'این دست برای ${widget.opponent.name} ثبت شد.';
    });
  }

  @override
  Widget build(BuildContext context) {
    final statusText = isGameOver
        ? resultTitle
        : isOpponentThinking
            ? '${widget.opponent.name} در حال فکر کردنه...'
            : 'نوبت شماست';

    return Scaffold(
      appBar: AppBar(
        title: const Text('دوز / XOX'),
        actions: [
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تنظیمات بازی در نسخه بعدی اضافه می‌شود.')),
              );
            },
            icon: const Icon(Icons.more_horiz_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
          children: [
            Row(
              children: [
                PlayerCard(
                  player: me,
                  symbol: 'X',
                  color: AppColors.blue,
                  isActive: currentTurn == 'X',
                ),
                const SizedBox(width: 12),
                PlayerCard(
                  player: PlayerModel(
                    name: widget.opponent.name,
                    avatarEmoji: widget.opponent.avatarEmoji,
                    score: widget.opponent.score,
                    level: widget.opponent.level,
                    isSystem: widget.opponent.isSystem,
                  ),
                  symbol: 'O',
                  color: AppColors.pink,
                  isActive: currentTurn == 'O',
                ),
              ],
            ),
            const SizedBox(height: 16),
            _ScoreStrip(
              statusText: statusText,
              myWins: myWins,
              opponentWins: opponentWins,
              draws: draws,
              isOpponentThinking: isOpponentThinking,
              isGameOver: isGameOver,
            ),
            const SizedBox(height: 18),
            _Board(cells: board, onTap: _onCellTap),
            const SizedBox(height: 16),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: isGameOver
                  ? _ResultCard(
                      key: const ValueKey('result'),
                      title: resultTitle,
                      subtitle: resultSubtitle,
                    )
                  : const _PlayingTip(key: ValueKey('tip')),
            ),
            const SizedBox(height: 16),
            if (isGameOver)
              PrimaryButton(
                text: 'بازی دوباره',
                icon: Icons.refresh_rounded,
                onPressed: _resetGame,
              )
            else
              Row(
                children: [
                  SizedBox(
                    width: 58,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('چت در نسخه بعدی اضافه می‌شود.')),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: AppColors.surface,
                        foregroundColor: AppColors.text,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: const BorderSide(color: AppColors.border),
                        ),
                      ),
                      child: const Icon(Icons.chat_bubble_outline_rounded),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: PrimaryButton(
                      text: 'تسلیم شدن',
                      icon: Icons.flag_rounded,
                      isSecondary: true,
                      onPressed: _surrender,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}

class _ScoreStrip extends StatelessWidget {
  const _ScoreStrip({
    required this.statusText,
    required this.myWins,
    required this.opponentWins,
    required this.draws,
    required this.isOpponentThinking,
    required this.isGameOver,
  });

  final String statusText;
  final int myWins;
  final int opponentWins;
  final int draws;
  final bool isOpponentThinking;
  final bool isGameOver;

  @override
  Widget build(BuildContext context) {
    final color = isGameOver
        ? AppColors.green
        : isOpponentThinking
            ? AppColors.purple
            : AppColors.blue;

    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Row(
        children: [
          Icon(
            isGameOver
                ? Icons.emoji_events_rounded
                : isOpponentThinking
                    ? Icons.hourglass_bottom_rounded
                    : Icons.touch_app_rounded,
            color: color,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              statusText,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
                fontSize: 14,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'برد: $myWins  مساوی: $draws  باخت: $opponentWins',
            style: const TextStyle(
              color: AppColors.mutedText,
              fontWeight: FontWeight.w800,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

class _Board extends StatelessWidget {
  const _Board({required this.cells, required this.onTap});

  final List<String> cells;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(34),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.purple.withOpacity(0.08),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: AspectRatio(
        aspectRatio: 1,
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 9,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemBuilder: (context, index) {
            final value = cells[index];
            final color = value == 'X' ? AppColors.blue : AppColors.pink;
            return InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () => onTap(index),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                decoration: BoxDecoration(
                  color: value.isEmpty ? AppColors.softSurface : color.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: value.isEmpty ? AppColors.border : color.withOpacity(0.28),
                  ),
                ),
                alignment: Alignment.center,
                child: AnimatedScale(
                  scale: value.isEmpty ? 0.4 : 1,
                  duration: const Duration(milliseconds: 190),
                  child: Text(
                    value,
                    style: TextStyle(
                      color: color,
                      fontSize: 49,
                      fontWeight: FontWeight.w900,
                      shadows: [
                        Shadow(
                          color: color.withOpacity(0.18),
                          blurRadius: 15,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({super.key, required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFE9DC), Color(0xFFEDE9FF)],
        ),
      ),
      child: Row(
        children: [
          const Text('🏆', style: TextStyle(fontSize: 34)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.text,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlayingTip extends StatelessWidget {
  const _PlayingTip({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFEEE3), Color(0xFFECE8FF)],
        ),
      ),
      child: const Row(
        children: [
          Icon(Icons.wb_twilight_rounded, color: AppColors.primary),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'حس بازی‌های قدیمی، با ظاهر مدرن و تمیز',
              style: TextStyle(
                color: AppColors.text,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
