import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/game_card.dart';
import '../widgets/primary_button.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
          children: [
            const _TopBar(),
            const SizedBox(height: 18),
            const _HeroCard(),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('بازی‌های نوستالژی', style: Theme.of(context).textTheme.titleLarge),
                TextButton(
                  onPressed: () {},
                  child: const Text('همه بازی‌ها'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.05,
              children: [
                GameCard(
                  title: 'دوز / XOX',
                  subtitle: 'شروع سریع',
                  icon: '❌⭕',
                  color: AppColors.blue,
                  onTap: () => _startQuickGame(context),
                ),
                const GameCard(
                  title: 'سنگ کاغذ قیچی',
                  subtitle: 'به‌زودی',
                  icon: '✊',
                  color: AppColors.yellow,
                ),
                const GameCard(
                  title: 'چهار در یک ردیف',
                  subtitle: 'به‌زودی',
                  icon: '🔴',
                  color: AppColors.purple,
                ),
                const GameCard(
                  title: 'حدس کلمه',
                  subtitle: 'به‌زودی',
                  icon: '❓',
                  color: AppColors.pink,
                ),
              ],
            ),
            const SizedBox(height: 22),
            PrimaryButton(
              text: 'بازی سریع',
              icon: Icons.flash_on_rounded,
              onPressed: () => _startQuickGame(context),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: PrimaryButton(
                    text: 'رتبه‌بندی',
                    icon: Icons.leaderboard_rounded,
                    isSecondary: true,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PrimaryButton(
                    text: 'اشتراک ویژه',
                    icon: Icons.workspace_premium_rounded,
                    isSecondary: true,
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('بخش اشتراک در نسخه بعدی اضافه می‌شود.')),
                      );
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MatchmakingScreen()),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
          ),
          alignment: Alignment.center,
          child: const Text('🙂', style: TextStyle(fontSize: 24)),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'سلام، خوش اومدی',
                style: TextStyle(
                  color: AppColors.mutedText,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'آماده رقابتی؟',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(
            children: [
              Text('🪙'),
              SizedBox(width: 6),
              Text(
                '۲۴۵۰',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: AppColors.text,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color(0xFFFFE6D2),
            Color(0xFFEDE5FF),
            Color(0xFFDDF0FF),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.15),
            blurRadius: 28,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            left: -10,
            bottom: -18,
            child: Text(
              '🕹️',
              style: TextStyle(fontSize: 70, color: AppColors.primary.withOpacity(0.6)),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.72),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Text(
                  'نسخه اولیه MVP',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: AppColors.purple,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text('بازی‌خونه', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 6),
              const Text(
                'بازی‌های خاطره‌انگیز، رقابت مدرن',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.mutedText,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 18),
              const Row(
                children: [
                  _MiniInfo(icon: '⚡', text: 'بازی سریع'),
                  SizedBox(width: 8),
                  _MiniInfo(icon: '🏆', text: 'رتبه‌بندی'),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniInfo extends StatelessWidget {
  const _MiniInfo({required this.icon, required this.text});

  final String icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.78),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Text(icon),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppColors.text,
            ),
          ),
        ],
      ),
    );
  }
}
