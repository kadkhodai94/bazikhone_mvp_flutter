import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/game_card.dart';
import '../widgets/primary_button.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
          children: [
            const _TopBar(),
            const SizedBox(height: 16),
            const _HeroCard(),
            const SizedBox(height: 22),
            Text('بازی‌های نوستالژی', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.05,
              children: [
                GameCard(
                  title: 'دوز / XOX',
                  subtitle: 'شروع سریع و رقابتی',
                  icon: 'X O',
                  color: AppColors.blue,
                  isAvailable: true,
                  onTap: () => _startQuickGame(context),
                ),
                const GameCard(
                  title: 'سنگ کاغذ قیچی',
                  subtitle: 'به‌زودی',
                  icon: '✊',
                  color: AppColors.yellow,
                ),
                const GameCard(
                  title: 'چهار در یک ردیف',
                  subtitle: 'به‌زودی',
                  icon: '●●',
                  color: AppColors.purple,
                ),
                const GameCard(
                  title: 'حدس کلمه',
                  subtitle: 'به‌زودی',
                  icon: '?',
                  color: AppColors.pink,
                ),
              ],
            ),
            const SizedBox(height: 22),
            PrimaryButton(
              text: 'بازی سریع',
              icon: Icons.flash_on_rounded,
              onPressed: () => _startQuickGame(context),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: PrimaryButton(
                    text: 'رتبه‌بندی',
                    icon: Icons.leaderboard_rounded,
                    isSecondary: true,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const LeaderboardScreen()),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: PrimaryButton(
                    text: 'اشتراک ویژه',
                    icon: Icons.workspace_premium_rounded,
                    isSecondary: true,
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('اشتراک ویژه در نسخه بعدی فعال می‌شود.')),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            const _TodayMissionCard(),
          ],
        ),
      ),
    );
  }

  void _startQuickGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MatchmakingScreen()),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.035),
                blurRadius: 16,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: const Text('🙂', style: TextStyle(fontSize: 24)),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'سلام، خوش اومدی',
                style: TextStyle(
                  color: AppColors.mutedText,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              SizedBox(height: 2),
              Text(
                'آماده رقابتی؟',
                style: TextStyle(
                  color: AppColors.text,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border),
          ),
          child: const Row(
            children: [
              Icon(Icons.monetization_on_rounded, color: AppColors.yellow, size: 20),
              SizedBox(width: 6),
              Text(
                '۲۴۵۰',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: AppColors.text,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 210,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(34),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color(0xFFFFE8D6),
            Color(0xFFF2E9FF),
            Color(0xFFDDF3FF),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.13),
            blurRadius: 30,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            left: -4,
            bottom: -8,
            child: Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.38),
                borderRadius: BorderRadius.circular(30),
              ),
              alignment: Alignment.center,
              child: const Text('🕹️', style: TextStyle(fontSize: 52)),
            ),
          ),
          Positioned(
            left: 66,
            top: 16,
            child: Text('✦', style: TextStyle(color: AppColors.purple.withOpacity(0.45), fontSize: 22)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.72),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Text(
                  'نسخه دوم MVP',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: AppColors.purple,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text('بازی‌خونه', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 6),
              const Text(
                'بازی‌های خاطره‌انگیز، رقابت مدرن',
                style: TextStyle(
                  fontSize: 14,
                  color: AppColors.mutedText,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Spacer(),
              const Row(
                children: [
                  _MiniInfo(icon: Icons.flash_on_rounded, text: 'سریع'),
                  SizedBox(width: 8),
                  _MiniInfo(icon: Icons.emoji_events_rounded, text: 'رقابتی'),
                  SizedBox(width: 8),
                  _MiniInfo(icon: Icons.auto_awesome_rounded, text: 'نوستالژی'),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniInfo extends StatelessWidget {
  const _MiniInfo({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.78),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.primary, size: 17),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(
              color: AppColors.text,
              fontWeight: FontWeight.w900,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

class _TodayMissionCard extends StatelessWidget {
  const _TodayMissionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
      ),
      child: const Row(
        children: [
          Icon(Icons.local_fire_department_rounded, color: AppColors.primary, size: 30),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ماموریت امروز',
                  style: TextStyle(
                    color: AppColors.text,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '۳ دست دوز بازی کن و ۵۰ سکه بگیر',
                  style: TextStyle(
                    color: AppColors.mutedText,
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_left_rounded, color: AppColors.mutedText),
        ],
      ),
    );
  }
}
