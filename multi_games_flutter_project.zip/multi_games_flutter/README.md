# Multi Games Flutter

این پروژه نسخه Flutter اپ چندبازی HTML است.

## نسخه اصلی
فایل اصلی بدون تغییر در این مسیر قرار دارد:

`assets/www/index.html`

رنگ‌بندی، تم و صفحه‌های بازی دست‌نخورده مانده‌اند و فقط داخل WebView اجرا می‌شوند.

## ساخت APK روی سیستم
```bash
flutter pub get
flutter build apk --release
```

خروجی:
`build/app/outputs/flutter-apk/app-release.apk`

## ساخت APK با GitHub Actions
پروژه را داخل GitHub آپلود کنید. سپس از تب Actions، workflow ساخت APK را اجرا کنید.
