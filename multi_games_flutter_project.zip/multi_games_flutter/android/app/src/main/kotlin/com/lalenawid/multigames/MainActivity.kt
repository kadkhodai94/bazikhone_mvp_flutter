package com.lalenawid.multigames

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
